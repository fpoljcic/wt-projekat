let Kalendar = (function () {

    //ovdje idu privatni atributi
    let current_date;
    let current_month;
    let months = ["Januar", "Februar", "Mart", "April", "Maj", "Juni", "Juli", "August", "Septembar", "Oktobar", "November", "December"];
    let nmb_days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let prva_sedmica = false;
    let periodicna=[{dan:2,semestar:"zimski",pocetak:"12:12",kraj:"13:15",naziv:"nazivv",predavac:"Predavac"}];
    let vanredna=[{datum:"8.11.2019",pocetak:"12:12",kraj:"13:15",naziv:"nazivv",predavac:"Predavac"}];
    let avanredna=[]

    window.onload = function () {
        current_date = new Date();
        current_month = current_date.getMonth();
        if (current_month === 11) {
            document.getElementById("next-month").disabled = true;
        }
        if (current_month === 0) {
            document.getElementById("previous-month").disabled = true;
        }
        //dodati event listenere
        document.getElementById("previous-month").addEventListener("click", function (ev) {
            prethodni();
        });
        document.getElementById("next-month").addEventListener("click", function (ev) {
            sljedeci();
        });
        Kalendar.iscrtajKalendar(document.getElementById("calendar"), current_month);
    }

    function obojiZauzecaImpl(nesto) {
        //implementacija ide ovdje

        //bojenje vanrednih zauzeca
        let broj_vanrednih=vanredna.length;
        for(var i=0;i< broj_vanrednih;i++){

        }
    }

    function ucitajPodatkeImpl(periodicna, vanredna) {
        //implementacija ide ovdje

    }
    function iscrtajKalendar(kalendarRef, mjesec) {
        let c_month = mjesec;
        current_date = new Date();

        ///Ispisivanje naziva mjeseca
        document.getElementById("month-indicator").innerHTML = months[current_month];

        //Iscrtavanje grida sa datumima
        let second_grid = document.createElement("div");
        second_grid.className = "second-grid";
        second_grid.id = "second-grid" + months[c_month];
        kalendarRef.appendChild(second_grid);

        let date_grid = document.createElement("div");
        date_grid.className = "date-grid";
        date_grid.id = "datte-grid" + months[c_month];
        document.getElementById("second-grid" + months[c_month]).appendChild(date_grid);

        //iscrtavanje datuma
        //Dohvatiti broj dana mjeseca
        let num_days = nmb_days[c_month];
        //Odrediti dan prvog u mjesecu
        let prvi = getFirstDay(c_month);
        let i, j, granica;
        //Pomjeriti prvi na odgovarajuci dan
        if (prvi === 0) granica = 6;
        else if (prvi === 1) granica = 0;
        else if (prvi === 2) granica = 1;
        else if (prvi === 3) granica = 2;
        else if (prvi === 4) granica = 3;
        else if (prvi === 5) granica = 4;
        else granica = 5;

        //Određivanje tekuće sedmice (pon i ned date)

        let current_week_mon, current_week_sun;
        if (current_date.getDay === 0)
            current_week_mon = current_date.getDate() - 6;
        else if (current_date.getDay === 1) current_week_mon = current_date.getDate();
        else if (current_date.getDay === 2) current_week_mon = current_date.getDate() - 1;
        else if (current_date.getDay === 3) current_week_mon = current_date.getDate() - 2;
        else if (current_date.getDay === 4) current_week_mon = current_date.getDate() - 3;
        else if (current_date.getDay === 5) current_week_mon = current_date.getDate() - 4;
        else current_week_mon = current_date.getDate() - 5;
        current_week_sun = current_week_mon + 6;

        prva_sedmica = false;
        var br_datuma = 0;

        let dan_prvog_u_mjesecu = getFirstDay(current_date.getMonth());
        if (current_date.getDate() < 6 && dan_prvog_u_mjesecu !== 1) {
            prva_sedmica = true;

            if (getFirstDay(current_date.getMonth()) === 0) br_datuma = 1;
            else if (dan_prvog_u_mjesecu === 2) br_datuma = 6;
            else if (dan_prvog_u_mjesecu === 3) br_datuma = 5;
            else if (dan_prvog_u_mjesecu === 4) br_datuma = 4;
            else if (dan_prvog_u_mjesecu === 5) br_datuma = 3;
            else { br_datuma = 2; }

        }
        for (j = 0; j < granica; j++) {

            var divv = document.createElement("div");
            divv.className = "prazan_div";
            if (prva_sedmica) {
                divv.id = "current-week";
            }
            document.getElementById("datte-grid" + months[c_month]).appendChild(divv);
        }
        for (i = 1; i <= num_days; i++) {

            let grid_element = document.createElement("div");
            grid_element.className = "date-grid-element";
            if (prva_sedmica & br_datuma > 0) {
                grid_element.id = "current-week";
                br_datuma--;
            }
            else if (current_week_sun >= 7 && (i <= current_week_sun && i >= current_week_mon)) { grid_element.id = "current-week"; }

            let grid_date = document.createElement("div");
            grid_date.className = "date";
            grid_element.appendChild(grid_date);
            grid_date.innerHTML = i;

            let grid_date_slobodna = document.createElement("div");
            grid_date_slobodna.className = "slobodna";
            grid_element.appendChild(grid_date_slobodna);

            document.getElementById("datte-grid" + months[c_month]).appendChild(grid_element);
        }

    }
    function getFirstDay(c_month1) {
        var FirstDay = new Date(2019, c_month1, 1);
        return FirstDay.getDay();
    }
    function sljedeci() {

        document.getElementById("previous-month").disabled = false;

        if (current_month === 11) {
            document.getElementById("next-month").disabled = true;
        }
        else {
            current_month += 1;
            //Sakrij trenutni 
            document.getElementById("second-grid" + months[current_month - 1]).style.display = "none";

            //Provjera da li vec postoji naredni ali je skriven
            if (document.getElementById("second-grid" + months[current_month]) === null) {
                //ako ne postoji crtaj ga
                iscrtajKalendar(document.getElementById("calendar"), current_month);
            }
            else {
                //ako postoji prikazi ga
                document.getElementById("second-grid" + months[current_month]).style.display = "block";
                document.getElementById("month-indicator").innerHTML = months[current_month];
            }
            if (current_month === 11) {
                document.getElementById("next-month").disabled = true;
            }
        }
    }
    function prethodni() {
        document.getElementById("next-month").disabled = false;

        if (current_month === 0) {
            document.getElementById("previous-month").disabled = true;
        }
        else {
            current_month -= 1;
            //Sakrij trenutni
            document.getElementById("second-grid" + months[current_month + 1]).style.display = "none";

            //Provjera da li vec postoji naredni ali je skriven
            if (document.getElementById("second-grid" + months[current_month]) === null) {
                //ako ne postoji crtaj ga
                iscrtajKalendar(document.getElementById("calendar"), current_month);
            }
            else {
                //ako postoji prikazi ga
                document.getElementById("second-grid" + months[current_month]).style.display = "block";
                document.getElementById("month-indicator").innerHTML = months[current_month];
            }
            if (current_month === 0) {
                document.getElementById("previous-month").disabled = true;
            }
        }

    }
    return {

        obojiZauzeca: obojiZauzecaImpl,
        ucitajPodatke: ucitajPodatkeImpl,
        iscrtajKalendar: iscrtajKalendar
    }
}());
    //primjer korištenja modula
    //Kalendar.obojiZauzeca(document.getElementById(“kalendar”),1,”1-15”,”12:00”,”13:30”);







