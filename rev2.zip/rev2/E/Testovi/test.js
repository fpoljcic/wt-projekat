// Napomena: Testovi za prve dvije metode su za novembar 2019. godine, sala 0-01, termin za salu = od 9:00 do 11:00
// Testirati u novembru 2019.

let assert = chai.assert;
describe('Kalendar', function() {
 describe('obojiZauzeca() i ucitajPodatke()', function() {

    //Test 1
    it('Pozivanje obojiZauzeca kada podaci nisu učitani: očekivana vrijednost da se ne oboji niti jedan dan', function() {
        var trenutniMjesec = 10;
        var sala = "0-01";
        var pocetak = "09:00";
        var kraj = "11:00";
        Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec); // trenutni mjesec
        Kalendar.obojiZauzeca(document.getElementById("mojKalendar"), trenutniMjesec, sala, pocetak, kraj);
        let kalendarRef = document.getElementById("mojKalendar");
        let brojObojenih = 0;

        // ne uzimamo prvi red jer je to naziv dana u sedmici
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {
                if(celija.classList.contains("zauzeta")) {
                    brojObojenih++;
                }
            }
                
        }
        
        assert.equal(brojObojenih, 0,"Broj obojenih mora biti 0");
    });


    //Test 2
    it('Pozivanje obojiZauzeca gdje u zauzećima postoje duple vrijednosti za zauzeće istog termina: očekivano je da se dan oboji bez obzira što postoje duple vrijednosti', function() {
    var trenutniMjesec = 10;
    var sala = "0-01";
    var pocetak = "09:00";
    var kraj = "11:00";
    
    var periodicna = [
        {
            dan: 4,
            semestar: "zimski",
            pocetak: "09:00",
            kraj: "10:30",
            naziv: "0-01",
            predavac: "Richard Feynman"
        },

        {
            dan: 3,
            semestar: "zimski",
            pocetak: "10:00",
            kraj: "12:30",
            naziv: "0-02",
            predavac: "Pčelica Maja"
        },
    
        {
            dan: 2,
            semestar: "zimski",
            pocetak: "14:00",
            kraj: "15:00",
            naziv: "0-02",
            predavac: "Nikola Tesla"
        },
    
        {
            dan: 1,
            semestar: "ljetni",
            pocetak: "15:00",
            kraj: "17:00",
            naziv: "VA1",
            predavac: "Arhimed"
        },
    
        {
            dan: 4,
            semestar: "ljetni",
            pocetak: "16:00",
            kraj: "17:30",
            naziv: "MA",
            predavac: "Albert Einstein"
        }
    ];
  
    
    var vanredna = [
        {
            datum: "23.11.2019",
            pocetak: "09:00",
            kraj: "12:00",
            naziv: "0-01",
            predavac: "Eustahije Brzić"
        },
    
        {
            datum: "24.12.2019",
            pocetak: "14:00",
            kraj: "15:00",
            naziv: "0-02",
            predavac: "Janko Strižić"
        },
    
        {
            datum: "18.10.2019",
            pocetak: "17:00",
            kraj: "17:45",
            naziv: "EE1",
            predavac: "Eustahije Brzić"
        }
    
    ];

    periodicna[1] = periodicna[0];

    Kalendar.ucitajPodatke(periodicna, vanredna);
    Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec); // trenutni mjesec
    Kalendar.obojiZauzeca(document.getElementById("mojKalendar"), trenutniMjesec, sala, pocetak, kraj);
    let kalendarRef = document.getElementById("mojKalendar");
    let brojObojenih = 0;

    // ne uzimamo prvi red jer je to naziv dana u sedmici
    for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
        for(var j=0, celija; celija = red.cells[j]; j++) {
            if(celija.classList.contains("zauzeta")) {
                brojObojenih++;
            }
        }
            
    }
    
    assert.equal(brojObojenih, 6,"Broj obojenih mora biti 6");
    });



    //Test 3
    it('Pozivanje obojiZauzece kada u podacima postoji periodično zauzeće za drugi semestar: očekivano je da se ne oboji zauzeće', function() {
        var trenutniMjesec = 10;
        var sala = "0-01";
        var pocetak = "09:00";
        var kraj = "11:00";


        var periodicna = [
            {
                dan: 4,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Richard Feynman"
            },

            {
                dan: 3,
                semestar: "ljetni",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Pčelica Maja"
            },
        
            {
                dan: 2,
                semestar: "zimski",
                pocetak: "14:00",
                kraj: "15:00",
                naziv: "0-02",
                predavac: "Nikola Tesla"
            },
        
            {
                dan: 1,
                semestar: "ljetni",
                pocetak: "15:00",
                kraj: "17:00",
                naziv: "VA1",
                predavac: "Arhimed"
            },
        
            {
                dan: 4,
                semestar: "ljetni",
                pocetak: "16:00",
                kraj: "17:30",
                naziv: "MA",
                predavac: "Albert Einstein"
            }
        ];
    
        
        var vanredna = [
            {
                datum: "23.11.2019",
                pocetak: "09:00",
                kraj: "12:00",
                naziv: "0-01",
                predavac: "Eustahije Brzić"
            },
        
            {
                datum: "24.12.2019",
                pocetak: "14:00",
                kraj: "15:00",
                naziv: "0-02",
                predavac: "Janko Strižić"
            },
        
            {
                datum: "18.10.2019",
                pocetak: "17:00",
                kraj: "17:45",
                naziv: "EE1",
                predavac: "Eustahije Brzić"
            }
        
        ];


        Kalendar.ucitajPodatke(periodicna, vanredna);
        Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec); // trenutni mjesec
        Kalendar.obojiZauzeca(document.getElementById("mojKalendar"), trenutniMjesec, sala, pocetak, kraj);
        let kalendarRef = document.getElementById("mojKalendar");
        let brojObojenih = 0;

        // ne uzimamo prvi red jer je to naziv dana u sedmici
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {
                if(celija.classList.contains("zauzeta")) {
                    brojObojenih++;
                }
            }
                
        }
        
        assert.equal(brojObojenih, 6,"Broj obojenih mora biti 6");
    });



    //Test 4
    it('Pozivanje obojiZauzece kada u podacima postoji zauzeće termina ali u drugom mjesecu: očekivano je da se ne oboji zauzeće', function() {
        var trenutniMjesec = 10;
        var sala = "0-01";
        var pocetak = "09:00";
        var kraj = "11:00";


        var periodicna = [
            {
                dan: 4,
                semestar: "ljetni",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Richard Feynman"
            },

            {
                dan: 3,
                semestar: "ljetni",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Pčelica Maja"
            },
        
            {
                dan: 2,
                semestar: "zimski",
                pocetak: "14:00",
                kraj: "15:00",
                naziv: "0-02",
                predavac: "Nikola Tesla"
            },
        
            {
                dan: 1,
                semestar: "ljetni",
                pocetak: "15:00",
                kraj: "17:00",
                naziv: "VA1",
                predavac: "Arhimed"
            },
        
            {
                dan: 4,
                semestar: "ljetni",
                pocetak: "16:00",
                kraj: "17:30",
                naziv: "MA",
                predavac: "Albert Einstein"
            }
        ];
    
        
        var vanredna = [
            {
                datum: "23.12.2019",
                pocetak: "09:00",
                kraj: "12:00",
                naziv: "0-01",
                predavac: "Eustahije Brzić"
            },
        
            {
                datum: "24.12.2019",
                pocetak: "14:00",
                kraj: "15:00",
                naziv: "0-02",
                predavac: "Janko Strižić"
            },
        
            {
                datum: "18.10.2019",
                pocetak: "17:00",
                kraj: "17:45",
                naziv: "EE1",
                predavac: "Eustahije Brzić"
            }
        
        ];


        Kalendar.ucitajPodatke(periodicna, vanredna);
        Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec); // trenutni mjesec
        Kalendar.obojiZauzeca(document.getElementById("mojKalendar"), trenutniMjesec, sala, pocetak, kraj);
        let kalendarRef = document.getElementById("mojKalendar");
        let brojObojenih = 0;

        // ne uzimamo prvi red jer je to naziv dana u sedmici
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {
                if(celija.classList.contains("zauzeta")) {
                    brojObojenih++;
                }
            }
                
        }
        
        assert.equal(brojObojenih, 0,"Broj obojenih mora biti 0");
    });



    //Test 5
    it('Pozivanje obojiZauzece kada su u podacima svi termini u mjesecu zauzeti: očekivano je da se svi dani oboje', function() {
        var trenutniMjesec = 10;
        var sala = "0-01";
        var pocetak = "09:00";
        var kraj = "11:00";
        var trenutnaGodina = 2019;


        var periodicna = [
            {
                dan: 0,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Richard Feynman"
            },

            {
                dan: 1,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Pčelica Maja"
            },
        
            {
                dan: 2,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Nikola Tesla"
            },
        
            {
                dan: 3,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Nikola Tesla"
            },
        
            {
                dan: 4,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Nikola Tesla"
            },

            {
                dan: 5,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Nikola Tesla"
            },

            {
                dan: 6,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Nikola Tesla"
            }
        ];
    
        
        var vanredna = [];


        Kalendar.ucitajPodatke(periodicna, vanredna);
        Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec); // trenutni mjesec
        Kalendar.obojiZauzeca(document.getElementById("mojKalendar"), trenutniMjesec, sala, pocetak, kraj);
        let kalendarRef = document.getElementById("mojKalendar");
        let brojObojenih = 0;


        // ne uzimamo prvi red jer je to naziv dana u sedmici
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {
                if(celija.classList.contains("zauzeta")) {
                    brojObojenih++;
                }
            }
                
        }
        
        assert.equal(brojObojenih, 30,"Broj obojenih mora biti " + 30);
    });



    //Test 6
    it('Dva puta uzastopno pozivanje obojiZauzece: očekivano je da boja zauzeća ostane ista', function() {
        var trenutniMjesec = 10;
        var sala = "0-01";
        var pocetak = "09:00";
        var kraj = "11:00";


        var periodicna = [
            {
                dan: 4,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Richard Feynman"
            },

            {
                dan: 3,
                semestar: "ljetni",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Pčelica Maja"
            },
        
            {
                dan: 2,
                semestar: "zimski",
                pocetak: "14:00",
                kraj: "15:00",
                naziv: "0-02",
                predavac: "Nikola Tesla"
            },
        
            {
                dan: 1,
                semestar: "ljetni",
                pocetak: "15:00",
                kraj: "17:00",
                naziv: "VA1",
                predavac: "Arhimed"
            },
        
            {
                dan: 4,
                semestar: "ljetni",
                pocetak: "16:00",
                kraj: "17:30",
                naziv: "MA",
                predavac: "Albert Einstein"
            }
        ];
    
        
        var vanredna = [
            {
                datum: "23.11.2019",
                pocetak: "09:00",
                kraj: "12:00",
                naziv: "0-01",
                predavac: "Eustahije Brzić"
            },
        
            {
                datum: "24.12.2019",
                pocetak: "14:00",
                kraj: "15:00",
                naziv: "0-02",
                predavac: "Janko Strižić"
            },
        
            {
                datum: "18.10.2019",
                pocetak: "17:00",
                kraj: "17:45",
                naziv: "EE1",
                predavac: "Eustahije Brzić"
            }
        
        ];


        Kalendar.ucitajPodatke(periodicna, vanredna);
        Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec); // trenutni mjesec
        Kalendar.obojiZauzeca(document.getElementById("mojKalendar"), trenutniMjesec, sala, pocetak, kraj);
        let kalendarRef = document.getElementById("mojKalendar");


        // ne uzimamo prvi red jer je to naziv dana u sedmici
        var zauzeto1 = [];
        var brojac = 0;
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {

                if(!celija.classList.contains("border-less"))
                    brojac++;

                if(celija.classList.contains("zauzeta")) {
                    zauzeto1.push(brojac);
                }
            }
                
        }



        Kalendar.obojiZauzeca(document.getElementById("mojKalendar"), trenutniMjesec, sala, pocetak, kraj);


        // ne uzimamo prvi red jer je to naziv dana u sedmici
        var zauzeto2 = [];
        var brojac = 0;
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {

                if(!celija.classList.contains("border-less"))
                    brojac++;

                if(celija.classList.contains("zauzeta")) {
                    zauzeto2.push(brojac);
                }
            }
                
        }

    
        
        var isti = new Boolean(true);


        if (zauzeto1.length != zauzeto2.length) 
            isti = false;

        if(isti.valueOf() == true) {
            for (var i = 0; i < zauzeto1.length; i++) {
                if (zauzeto1[i] != zauzeto2[i]) 
                    isti = false;
            }
        }
    

        assert.equal(isti.valueOf(),true,'Očekivano je da boja zauzeća ostane ista');
        
        
    });


    //Test 7
    it('Pozivanje ucitajPodatke, obojiZauzeca, ucitajPodatke - drugi podaci, obojiZauzeca: očekivano da se zauzeća iz prvih podataka ne ostanu obojena, tj. primjenjuju se samo posljednje učitani podaci', function() {
        var trenutniMjesec = 10;
        var sala = "0-01";
        var pocetak = "09:00";
        var kraj = "11:00";


        var periodicna = [
            {
                dan: 4,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Richard Feynman"
            },

            {
                dan: 3,
                semestar: "ljetni",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Pčelica Maja"
            },
        
            {
                dan: 2,
                semestar: "zimski",
                pocetak: "14:00",
                kraj: "15:00",
                naziv: "0-02",
                predavac: "Nikola Tesla"
            },
        
            {
                dan: 1,
                semestar: "ljetni",
                pocetak: "15:00",
                kraj: "17:00",
                naziv: "VA1",
                predavac: "Arhimed"
            },
        
            {
                dan: 4,
                semestar: "ljetni",
                pocetak: "16:00",
                kraj: "17:30",
                naziv: "MA",
                predavac: "Albert Einstein"
            }
        ];
    
        
        var vanredna = [
            {
                datum: "23.11.2019",
                pocetak: "09:00",
                kraj: "12:00",
                naziv: "0-01",
                predavac: "Eustahije Brzić"
            },
        
            {
                datum: "24.12.2019",
                pocetak: "14:00",
                kraj: "15:00",
                naziv: "0-02",
                predavac: "Janko Strižić"
            },
        
            {
                datum: "18.10.2019",
                pocetak: "17:00",
                kraj: "17:45",
                naziv: "EE1",
                predavac: "Eustahije Brzić"
            }
        
        ];


        Kalendar.ucitajPodatke(periodicna, vanredna);
        Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec); // trenutni mjesec
        Kalendar.obojiZauzeca(document.getElementById("mojKalendar"), trenutniMjesec, sala, pocetak, kraj); // vise zauzeca u novembru
        let kalendarRef = document.getElementById("mojKalendar");


        // ne uzimamo prvi red jer je to naziv dana u sedmici
        var zauzeto1 = [];
        var brojac = 0;
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {

                if(!celija.classList.contains("border-less"))
                    brojac++;

                if(celija.classList.contains("zauzeta")) {
                    zauzeto1.push(brojac);
                }
            }
                
        }

        periodicna[0].semestar = "ljetni"
        Kalendar.ucitajPodatke(periodicna, vanredna);
        Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec); // trenutni mjesec
        Kalendar.obojiZauzeca(document.getElementById("mojKalendar"), trenutniMjesec, sala, pocetak, kraj); // samo jedno zauzece u novembru


        // ne uzimamo prvi red jer je to naziv dana u sedmici
        var zauzeto2 = [];
        var brojac = 0;
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {

                if(!celija.classList.contains("border-less"))
                    brojac++;

                if(celija.classList.contains("zauzeta")) {
                    zauzeto2.push(brojac);
                }
            }
                
        }

    
        
        var isti = new Boolean(true);


        if (zauzeto1.length != zauzeto2.length) 
            isti = false;

        if(isti.valueOf() == true) {
            for (var i = 0; i < zauzeto1.length; i++) {
                if (zauzeto1[i] != zauzeto2[i]) 
                    isti = false;
            }
        }
    

        assert.equal(isti.valueOf(),false,'Očekivano je da se zauzeće promijeni');
    });


    //Tri testa po vlastitom odabiru:

    //Test 8
    it('Pozivanje obojiZauzeca kada se podaci odnose na godinu koja nije trenutna: očekivana vrijednost da se ne oboji niti jedan dan', function() {
        var trenutniMjesec = 10;
        var sala = "0-01";
        var pocetak = "09:00";
        var kraj = "11:00";


        var periodicna = [];
    
        
        var vanredna = [
            {
                datum: "23.11.2020",
                pocetak: "09:00",
                kraj: "12:00",
                naziv: "0-01",
                predavac: "Eustahije Brzić"
            },
        
            {
                datum: "24.12.2020",
                pocetak: "14:00",
                kraj: "15:00",
                naziv: "0-02",
                predavac: "Janko Strižić"
            },
        
            {
                datum: "18.10.2020",
                pocetak: "17:00",
                kraj: "17:45",
                naziv: "EE1",
                predavac: "Eustahije Brzić"
            }
        
        ];


        Kalendar.ucitajPodatke(periodicna, vanredna);
        Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec); // trenutni mjesec
        Kalendar.obojiZauzeca(document.getElementById("mojKalendar"), trenutniMjesec, sala, pocetak, kraj); // nema zauzeća
        let kalendarRef = document.getElementById("mojKalendar");


        // ne uzimamo prvi red jer je to naziv dana u sedmici
        var brojac = 0;
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {

                if(celija.classList.contains("zauzeta")) {
                    brojac++;
                }
            }
                
        }
    

        assert.equal(brojac,0,'Očekivano je da nema zauzetih dana');
    });

    //Test 9
    it('Pozivanje obojiZauzeca kada se svi podaci odnose na jedan mjesec koji nije trenutni: očekivana vrijednost da se ne oboji niti jedan dan osim za mjesec na koji se podaci odnose', function() {
        
        var sala = "0-01";
        var pocetak = "09:00";
        var kraj = "11:00";

        var periodicna = [];
    
        
        var vanredna = [
            {
                datum: "23.12.2019", // samo jedno zauzeće u decembru
                pocetak: "09:00",
                kraj: "12:00",
                naziv: "0-01",
                predavac: "Eustahije Brzić"
            },
        
            {
                datum: "24.12.2019",
                pocetak: "09:00",
                kraj: "10:00",
                naziv: "0-02",
                predavac: "Janko Strižić"
            },
        
            {
                datum: "25.12.2019",
                pocetak: "09:00",
                kraj: "10:00",
                naziv: "EE1",
                predavac: "Eustahije Brzić"
            }
        
        ];


        Kalendar.ucitajPodatke(periodicna,vanredna);

        for(var k = 0; k<12; k++) {
            var trenutniMjesec = k;

            if(k!=11) {
                Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec); // trenutni mjesec
                Kalendar.obojiZauzeca(document.getElementById("mojKalendar"), trenutniMjesec, sala, pocetak, kraj);
                let kalendarRef = document.getElementById("mojKalendar");
                let brojObojenih = 0;

                // ne uzimamo prvi red jer je to naziv dana u sedmici
                for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
                    for(var j=0, celija; celija = red.cells[j]; j++) {
                        if(celija.classList.contains("zauzeta")) {
                            brojObojenih++;
                        }
                    }
                }
                
                assert.equal(brojObojenih, 0,"Broj obojenih mora biti 0");
            }
            else {
                Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec); // trenutni mjesec
                Kalendar.obojiZauzeca(document.getElementById("mojKalendar"), trenutniMjesec, sala, pocetak, kraj);
                let kalendarRef = document.getElementById("mojKalendar");
                let brojObojenih = 0;

                // ne uzimamo prvi red jer je to naziv dana u sedmici
                for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
                    for(var j=0, celija; celija = red.cells[j]; j++) {
                        if(celija.classList.contains("zauzeta")) {
                            brojObojenih++;
                        }
                    }
                }
                
                assert.equal(brojObojenih, 1,"Broj obojenih mora biti 1");
            }


        }

        


    });


    //Test 10
    it('Pozivanje obojiZauzeca kada se sve rezervacije periodicne: očekivana vrijednost da se ne oboji niti jedan dan van akademske godine', function() {
        
        var sala = "0-01";
        var pocetak = "09:00";
        var kraj = "11:00";

        var periodicna = [
            {
                dan: 0,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Richard Feynman"
            },

            {
                dan: 1,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Pčelica Maja"
            },
        
            {
                dan: 2,
                semestar: "ljetni",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Nikola Tesla"
            },
        
            {
                dan: 3,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Nikola Tesla"
            },
        
            {
                dan: 4,
                semestar: "ljetni",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Nikola Tesla"
            },

            {
                dan: 5,
                semestar: "ljetni",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Nikola Tesla"
            },

            {
                dan: 6,
                semestar: "zimski",
                pocetak: "09:00",
                kraj: "10:30",
                naziv: "0-01",
                predavac: "Nikola Tesla"
            }
        ];
    
        
        var vanredna = [];


        Kalendar.ucitajPodatke(periodicna,vanredna);

        for(var k = 0; k<12; k++) {
            var trenutniMjesec = k;

            if(k >=5 && k<=8) {
                Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec); // trenutni mjesec
                Kalendar.obojiZauzeca(document.getElementById("mojKalendar"), trenutniMjesec, sala, pocetak, kraj);
                let kalendarRef = document.getElementById("mojKalendar");
                let brojObojenih = 0;

                // ne uzimamo prvi red jer je to naziv dana u sedmici
                for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
                    for(var j=0, celija; celija = red.cells[j]; j++) {
                        if(celija.classList.contains("zauzeta")) {
                            brojObojenih++;
                        }
                    }
                }
                
                assert.equal(brojObojenih, 0,"Broj obojenih mora biti 0 za mjesece van akademske godine za periodicne rezervacije");
            }
            

        }

        


    });




   
 });

 describe('iscrtajKalendar()', function() {

    //Test 1
    it('Pozivanje iscrtajKalendar za mjesec sa 30 dana: očekivano je da se prikaže 30 dana', function() {
        var trenutniMjesec = 10; // novembar ima 30 dana
        Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec);
        let kalendarRef = document.getElementById("mojKalendar");
        let brojDana = 0;

        // ne uzimamo prvi red jer je to naziv dana u sedmici
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {
                if(!celija.classList.contains("border-less")) {
                    brojDana++;
                }
            }
                
        }
        
        assert.equal(brojDana, 30,"Broj dana mora biti 30");
    });


    //Test 2
    it('Pozivanje iscrtajKalendar za mjesec sa 31 dan: očekivano je da se prikaže 31 dan', function() {
        var trenutniMjesec = 11; // decembar ima 31 dan
        Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec);
        let kalendarRef = document.getElementById("mojKalendar");
        let brojDana = 0;

        // ne uzimamo prvi red jer je to naziv dana u sedmici
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {
                if(!celija.classList.contains("border-less")) {
                    brojDana++;
                }
            }
                
        }
        
        assert.equal(brojDana, 31,"Broj dana mora biti 31");
    });



    //Test 3
    it('Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 1. dan u petak', function() {
        var trenutniMjesec = 10; // novembar 2019. pocinje u petak
        Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec);
        let kalendarRef = document.getElementById("mojKalendar");
        let brojac = 0;

        // ne uzimamo prvi red jer je to naziv dana u sedmici
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {
                if(!celija.classList.contains("border-less")) {
                    brojac++;
                    if(brojac == 1)
                    assert.equal(j, 4, "Novembar 2019. pocinje u petak");
                }
            }
                
        }   
        
    });



    //Test 4
    it('Pozivanje iscrtajKalendar za trenutni mjesec: očekivano je da je 30. dan u subotu', function() {
        var trenutniMjesec = 10; // 30. novembar 2019. je subota
        Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec);
        let kalendarRef = document.getElementById("mojKalendar");
        let brojac = 0;

        // ne uzimamo prvi red jer je to naziv dana u sedmici
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {
                if(!celija.classList.contains("border-less")) {
                    brojac++;
                    if(brojac == 30)
                        assert.equal(j, 5, "30. novembar 2019. je subota");
                }
            }
                
        }
        
    });



    //Test 5
    it('Pozivanje iscrtajKalendar za januar: očekivano je da brojevi dana idu od 1 do 31 počevši od utorka', function() {
        var trenutniMjesec = 0; // Januar 2019. ima 31 dan, počinje u utorak
        Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec);
        let kalendarRef = document.getElementById("mojKalendar");
        let brojac = 0;

        // ne uzimamo prvi red jer je to naziv dana u sedmici
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {
                if(!celija.classList.contains("border-less")) {
                    brojac++;
                    if(brojac == 1)
                        assert.equal(j,1, "Januar 2019. počinje u utorak")
                }
            }
        }

        
        assert.equal(brojac, 31, "Januar 2019. ima 31 dan");
    });


    // Dva testa po vlastitom izboru

    //Test 6
    it('Test februar - ima 28 dana', function() {
        var trenutniMjesec = 1; // Februar 2019. ima 28 dana
        Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec);
        let kalendarRef = document.getElementById("mojKalendar");
        let brojac = 0;

        // ne uzimamo prvi red jer je to naziv dana u sedmici
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {
                if(!celija.classList.contains("border-less")) {
                    brojac++;
                }
            }
        }
        
        assert.equal(brojac, 28, "Februar 2019. ima 28 dana");
    });


    //Test 7
    it('Test august - ima 31 dan, počinje u četvrtak', function() {
        var trenutniMjesec = 7; // August 2019. ima 31 dan, počinje u četvrtak
        Kalendar.iscrtajKalendar(document.getElementById("mojKalendar"), trenutniMjesec);
        let kalendarRef = document.getElementById("mojKalendar");
        let brojac = 0;

        // ne uzimamo prvi red jer je to naziv dana u sedmici
        for (var i = 1, red; red = kalendarRef.rows[i]; i++) {
            for(var j=0, celija; celija = red.cells[j]; j++) {
                if(!celija.classList.contains("border-less")) {
                    brojac++;
                    if(brojac == 1)
                        assert.equal(j,3, "August 2019. počinje u četvrtak")
                }
            }
        }

        assert.equal(brojac, 31, "August 2019. ima 31 dan");
    });


   
 });

});
