const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const path = require('path');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static('public'));

app.get('/rezervacija.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/html/rezervacija.html'));
});

app.get('/rezervacije', (req, res) => {
    fs.readFile('./zauzeca.json', 'utf8', function (err, data) {
        if (err) throw err;
        res.json(JSON.parse(data));
    });
});

app.post('/rezervisiVanredno', (req, res) => {
    String.prototype.replaceAll = function(searchStr, replaceStr) {
        var str = this;
        if(str.indexOf(searchStr) === -1)
            return str;
        return (str.replace(searchStr, replaceStr)).replaceAll(searchStr, replaceStr);
    }
    function dajBrojDanaUMjesecu(mjesec, godina){
        var daniUMjesecu = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31] 
        if(((godina % 100==0) && (godina % 400==0)) || (godina % 4==0 ))
            daniUMjesecu[1]=29;
        return daniUMjesecu[mjesec];
    }
    function danUSedmici(datum){
        var dpom = new Date(parseInt(datum.toString().split(".")[2]), parseInt(datum.toString().split(".")[1])-1, parseInt(datum.toString().split(".")[0]), 10, 33);
        var dan = dpom.getDay();
        dan--;
        if(dan<0)
            dan=6;
        return dan;
    }
    function dajDatume(dan,semestar){
        var datumi =[];
        if(semestar=="zimski"){
            var m = 0;
            for(var i=1; i<=dajBrojDanaUMjesecu(m,2019); i++){
                if(dan==danUSedmici(i +"." + (m+1)  + ".2019")){
                    var mjesec;
                    if(m+1<10)
                        mjesec = "0" + (m+1).toString();
                    else
                        mjesec = (m+1).toString();
                    datumi.push(i + "." + mjesec + ".2019");
                }
            }
            for(var j=9; j<12; j++){
                m = j;
                for(var i=1; i<=dajBrojDanaUMjesecu(m,2019); i++){
                    if(dan==danUSedmici(i +"." + (m+1)  + ".2019")){
                        var mjesec;
                        if(m+1<10)
                            mjesec = "0" + (m+1).toString();
                        else
                            mjesec = (m+1).toString();
                        datumi.push(i + "." + mjesec + ".2019");
                    }
                }
            }
        }
        else if(semestar=="ljetni"){
            for(var j=1; j<6; j++){
                var m = j;
                for(var i=1; i<=dajBrojDanaUMjesecu(m,2019); i++){
                    if(dan==danUSedmici(i +"." + (m+1)  + ".2019")){
                        var mjesec;
                        if(m+1<10)
                            mjesec = "0" + (m+1).toString();
                        else
                            mjesec = (m+1).toString();
                        datumi.push(i + "." + mjesec + ".2019");
                    }
                }
            }
        }
        return datumi;
    }
    function poklapanjeTermina(hp, mp, hk, mk, h1, m1, h2, m2) {
        if((h1+m1===h2+m2) || h1>h2 || (h1==h2 && m1>m2))
            return false;
        if(hk==h1 && mk==m1)
            return false;
        if(hp==h2 && mp==m2)
            return false;
        if(hp<=h1 && hk>=h2)
            return true;
        return (h1 < hp || h1 == hp && m1 <= mp) && (hp < h2 || hp == h2 && mp <= m2) || (h1 < hk || h1 == hk && m1 <= mk) && (hk < h2 || hk == h2 && mk <= m2);
    }
    fs.readFile('./zauzeca.json', 'utf8', function (err, data) {
        if (err) throw err;
        var zauzeca = JSON.parse(data);
        var greska=false;
        for(var i = 0; i < zauzeca.vanredna.length; i++) {
            if(JSON.stringify(zauzeca.vanredna[i]) == JSON.stringify(req.body)){
                greska=true;
                break;
            }
            if(req.body.datum.toString() == zauzeca.vanredna[i].datum.toString() && req.body.naziv.toString() == zauzeca.vanredna[i].naziv.toString() &&
                poklapanjeTermina(parseInt(zauzeca.vanredna[i].pocetak.toString().split(":")[0]),parseInt(zauzeca.vanredna[i].pocetak.toString().split(":")[1]), parseInt(zauzeca.vanredna[i].kraj.toString().split(":")[0]),parseInt(zauzeca.vanredna[i].kraj.toString().split(":")[1]),parseInt(req.body.pocetak.toString().split(":")[0]),parseInt(req.body.pocetak.toString().split(":")[1]),parseInt(req.body.kraj.toString().split(":")[0]),parseInt(req.body.kraj.toString().split(":")[1]))) {
                greska=true;
                break;
            }
        }
        for(var i = 0; i < zauzeca.periodicna.length; i++) {
            if(dajDatume(zauzeca.periodicna[i].dan,zauzeca.periodicna[i].semestar.toString()).find(element => element == req.body.datum.toString()) != undefined && req.body.naziv.toString() == zauzeca.periodicna[i].naziv.toString() &&
                poklapanjeTermina(parseInt(zauzeca.periodicna[i].pocetak.toString().split(":")[0]),parseInt(zauzeca.periodicna[i].pocetak.toString().split(":")[1]), parseInt(zauzeca.periodicna[i].kraj.toString().split(":")[0]),parseInt(zauzeca.periodicna[i].kraj.toString().split(":")[1]),parseInt(req.body.pocetak.toString().split(":")[0]),parseInt(req.body.pocetak.toString().split(":")[1]),parseInt(req.body.kraj.toString().split(":")[0]),parseInt(req.body.kraj.toString().split(":")[1]))) {
                greska=true;
                break;
            }
        }
        if(!greska){
            zauzeca.vanredna.push(req.body);
            const z = JSON.stringify(zauzeca);
            fs.writeFile('./zauzeca.json', z, err => {
                if (err) {
                    console.log('Neuspješno rezervisanje termina!', err);
                } else {
                    console.log('Vanredno zauzeće uspješno dodano!');
                }
            });
            res.json(zauzeca);
        }
        else {
            var greskaTekst = 'Nije moguće rezervisati salu ' + req.body.naziv + ' za navedeni datum ' + req.body.datum.replaceAll(".", "/") + ' i termin od ' + req.body.pocetak + ' do ' + req.body.kraj + '!';
            res.status(500).send(greskaTekst);
        }
    });
});

app.post('/rezervisiPeriodicne', (req, res) => {
    function danUSedmici(datum){
        var dpom = new Date(parseInt(datum.toString().split(".")[2]), parseInt(datum.toString().split(".")[1])-1, parseInt(datum.toString().split(".")[0]), 10, 33);
        var dan = dpom.getDay();
        dan--;
        if(dan<0)
            dan=6;
        return dan;
    }
    function semestarUGodini(datum){
        if(parseInt(datum.toString().split(".")[1])==1 || parseInt(datum.toString().split(".")[1])==10 || parseInt(datum.toString().split(".")[1])==11 || parseInt(datum.toString().split(".")[1])==12)
            return "zimski";
        else if(parseInt(datum.toString().split(".")[1])==2 || parseInt(datum.toString().split(".")[1])==3 || parseInt(datum.toString().split(".")[1])==4 || parseInt(datum.toString().split(".")[1])==5 || parseInt(datum.toString().split(".")[1])==6)
            return "ljetni";
        return "";
    }
    function poklapanjeTermina(hp, mp, hk, mk, h1, m1, h2, m2) {
        if((h1+m1===h2+m2) || h1>h2 || (h1==h2 && m1>m2))
            return false;
        if(hk==h1 && mk==m1)
            return false;
        if(hp==h2 && mp==m2)
            return false;
        if(hp<=h1 && hk>=h2)
            return true;
        return (h1 < hp || h1 == hp && m1 <= mp) && (hp < h2 || hp == h2 && mp <= m2) || (h1 < hk || h1 == hk && m1 <= mk) && (hk < h2 || hk == h2 && mk <= m2);
    }
    fs.readFile('./zauzeca.json', 'utf8', function (err, data) {
        if (err) throw err;
        var zauzeca = JSON.parse(data);
        var greska=false;
        for(var i = 0; i < zauzeca.periodicna.length; i++) {
            if(JSON.stringify(zauzeca.periodicna[i]) == JSON.stringify(req.body)) {
                greska=true;
                break;
            }
            if(parseInt(req.body.dan) == zauzeca.periodicna[i].dan && req.body.semestar.toString() == zauzeca.periodicna[i].semestar.toString() && req.body.naziv.toString() == zauzeca.periodicna[i].naziv.toString() &&
                poklapanjeTermina(parseInt(zauzeca.periodicna[i].pocetak.toString().split(":")[0]),parseInt(zauzeca.periodicna[i].pocetak.toString().split(":")[1]), parseInt(zauzeca.periodicna[i].kraj.toString().split(":")[0]),parseInt(zauzeca.periodicna[i].kraj.toString().split(":")[1]),parseInt(req.body.pocetak.toString().split(":")[0]),parseInt(req.body.pocetak.toString().split(":")[1]),parseInt(req.body.kraj.toString().split(":")[0]),parseInt(req.body.kraj.toString().split(":")[1]))) {
                greska=true;
                break;
            }
        }

        for(var j = 0; j < zauzeca.vanredna.length; j++) { 
            if(danUSedmici(zauzeca.vanredna[j].datum.toString()) == req.body.dan && semestarUGodini(zauzeca.vanredna[j].datum) == req.body.semestar.toString() && zauzeca.vanredna[j].naziv.toString() == req.body.naziv.toString() &&
            poklapanjeTermina(parseInt(req.body.pocetak.toString().split(":")[0]),parseInt(req.body.pocetak.toString().split(":")[1]), parseInt(req.body.kraj.toString().split(":")[0]),parseInt(req.body.kraj.toString().split(":")[1]),parseInt(zauzeca.vanredna[j].pocetak.toString().split(":")[0]),parseInt(zauzeca.vanredna[j].pocetak.toString().split(":")[1]),parseInt(zauzeca.vanredna[j].kraj.toString().split(":")[0]),parseInt(zauzeca.vanredna[j].kraj.toString().split(":")[1]))) {
                greska=true;
                break;
            }
        }
        
        if(!greska){
            zauzeca.periodicna.push(req.body);
            const z = JSON.stringify(zauzeca);
            fs.writeFile('./zauzeca.json', z, err => {
                if (err) {
                    console.log('Neuspješno rezervisanje termina!', err);
                } else {
                    console.log('Periodično zauzeće uspješno dodano!');
                }
            });
            res.json(zauzeca);
        }
        else {
            var greskaTekst = "Nije moguće rezervisati salu " + req.body.naziv + " za " + req.body.semestar + " semestar i termin od " + req.body.pocetak + " do " + req.body.kraj + "!";
            res.status(500).send(greskaTekst);
        }
    });
});

app.get('/sale.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/html/sale.html'));
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/html/pocetna.html'));
});

app.get('/pocetna.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/html/pocetna.html'));
});

app.post('/slike', (req, res) => {
    fs.readFile('./slike.json', 'utf8', function (err, data) {
        if (err) throw err;
        var urls = JSON.parse(data);
        var slike = { "url" :[], "zadnja": false};
        for (var i=0; i<urls.url.length; i++)
            if(i>=req.body.prva && i<=req.body.zadnja)
                slike.url.push(urls.url[i]);
        if(req.body.zadnja+1==urls.url.length)
            slike.zadnja=true;
        
        if(slike.url.length!=0)
            res.json(JSON.stringify(slike));
        else {
            res.status(500);
            res.json({ greska: 'Ne postoji niti jedna slika ili su poslati pogresni podaci!'});
        }
    });
});

app.get('/unos.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/html/unos.html'));
});

var server = app.listen(8080, function() {
    console.log('Slušam %d port!', server.address().port);
});