var d = new Date(2019,1, 10, 10, 33);
var trenutniMjesec=d.getMonth();
var trenutnaSala="";
var trenutniPocetak="";
var trenutniKraj="";
var mjeseci = ["Januar", "Februar", "Mart", "April", "Maj", "Juni", "Juli", "August", "Septembar", "Oktobar", "Novembar", "Decembar"];

let Kalendar = (function(){
    var redovnaZauzeca=[];
    var vanrednaZauzeca=[];
    
    function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj){ // U slučaju da kraj jednog termina bude npr. 12:00, a mi unesemo u polje za početak 12:00
        iscrtajKalendarImpl(kalendarRef,mjesec);                         // zauzeće se neće obojiti. Slično vrijedi i za gornju granicu tj. početak i kraj jednaki 
        if(sala!="" && pocetak!="" && kraj!="" ){   
            for(var k=0; k<redovnaZauzeca.length;k++) {
                if(redovnaZauzeca[k].naziv==sala && poklapanjeTermina(parseInt(redovnaZauzeca[k].pocetak.split(":")[0]),parseInt(redovnaZauzeca[k].pocetak.split(":")[1]), parseInt(redovnaZauzeca[k].kraj.split(":")[0]),parseInt(redovnaZauzeca[k].kraj.split(":")[1]),parseInt(pocetak.split(":")[0]),parseInt(pocetak.split(":")[1]),parseInt(kraj.split(":")[0]),parseInt(kraj.split(":")[1]))){
                    if(redovnaZauzeca[k].semestar=="zimski" && (mjeseci[mjesec]=="Januar" || mjeseci[mjesec]=="Oktobar" || mjeseci[mjesec]=="Novembar" || mjeseci[mjesec]=="Decembar"))
                        obojiRedovnaZauzeca(kalendarRef,redovnaZauzeca[k].dan);
                    else if(redovnaZauzeca[k].semestar=="ljetni" && (mjeseci[mjesec]=="Februar" || mjeseci[mjesec]=="Mart" || mjeseci[mjesec]=="April" || mjeseci[mjesec]=="Maj" || mjeseci[mjesec]=="Juni"))
                        obojiRedovnaZauzeca(kalendarRef,redovnaZauzeca[k].dan);
                }
            }
            for(var k=0; k<vanrednaZauzeca.length; k++) {
                var danZauzeca = vanrednaZauzeca[k].datum.substring(0,2);
                var mjesecZauzeca = vanrednaZauzeca[k].datum.substring(3,5);
            //  var godinaZauzeca = vanrednaZauzeca[k].datum.substring(6);
                if(danZauzeca.substring(0,1)=="0")
                    danZauzeca = danZauzeca.substring(1);
                if(mjesecZauzeca.substring(0,1)=="0")
                    mjesecZauzeca = mjesecZauzeca.substring(1);
                if(vanrednaZauzeca[k].naziv==sala && poklapanjeTermina(parseInt(vanrednaZauzeca[k].pocetak.split(":")[0]),parseInt(vanrednaZauzeca[k].pocetak.split(":")[1]), parseInt(vanrednaZauzeca[k].kraj.split(":")[0]),parseInt(vanrednaZauzeca[k].kraj.split(":")[1]),parseInt(pocetak.split(":")[0]),parseInt(pocetak.split(":")[1]),parseInt(kraj.split(":")[0]),parseInt(kraj.split(":")[1])))
                    obojiVanrednaZauzeca(kalendarRef,mjesec,danZauzeca,mjesecZauzeca);
            }
        }
    }

    function ucitajPodatkeImpl(periodicna, vanredna){
        redovnaZauzeca=[];
        vanrednaZauzeca=[];
        for(var k=0; k<periodicna.length; k++){
            if(!(periodicna[k].dan>=0 && periodicna[k].dan<=6) || !(periodicna[k].semestar=="zimski" || periodicna[k].semestar=="ljetni") || typeof periodicna[k].pocetak != "string" || typeof periodicna[k].kraj != "string" || typeof periodicna[k].naziv != "string" || typeof periodicna[k].predavac != "string")
                continue;
            if(periodicna[k].pocetak.length!=5 || periodicna[k].kraj.length!=5 || !(/^\d{2}:\d{2}$/.test(periodicna[k].pocetak)) || !(/^\d{2}:\d{2}$/.test(periodicna[k].kraj)))
                continue;
            redovnaZauzeca.push(periodicna[k]);
        }
        for(var k=0; k<vanredna.length; k++){
            if(typeof vanredna[k].datum != "string" || typeof vanredna[k].pocetak != "string" || typeof vanredna[k].kraj != "string" || typeof vanredna[k].naziv != "string" || typeof vanredna[k].predavac != "string")
                continue;
            if(!(/^\d{2}.\d{2}.\d{4}$/.test(vanredna[k].datum)) || !(/^\d{2}:\d{2}$/.test(vanredna[k].pocetak)) || !(/^\d{2}:\d{2}$/.test(vanredna[k].kraj)))
                continue;
            vanrednaZauzeca.push(vanredna[k]);
        }
    }

    function iscrtajKalendarImpl(kalendarRef, mjesec){
        var d = new Date();
        if(mjesec>=0 && mjesec<=11)
            document.getElementById('mjesec').innerHTML = mjeseci[mjesec] + " " + d.getFullYear();
        
        var dan=1;
        
        var prviDan = dajPrviDanUMjesecu(mjesec, d.getFullYear());
        var pronadjen = false;
        
        var tds = kalendarRef.getElementsByTagName("td");
        for(var i=7; i<tds.length; i++) {
            if(i-7<prviDan){
                tds[i].setAttribute("id", "slobodanDan");
                tds[i].innerHTML = "";
            }
            else{
                tds[i].setAttribute("id", "brojDan");
                tds[i].innerHTML = "";
            }
        }
        
        var brojDanaUMjesecu = dajBrojDanaUMjesecu(mjesec, d.getFullYear());        
        for(var i=2; i<8; i++){
            for(var j=0; j<7; j++){
                if(pronadjen){
                    if(brojDanaUMjesecu<dan){
                        if(i==6){
                            var k=35;
                            for(var l=0; l<7; l++)
                                if(l==j)
                                    k+=j;
                            for(var l=k; l<42; l++)
                                tds[l].setAttribute("id", "slobodanDan");
                        }
                        else{
                            var k=42;
                            for(var l=0; l<7; l++)
                                if(l==j)
                                    k+=j;
                            for(var l=k; l<tds.length; l++)
                                tds[l].setAttribute("id", "slobodanDan");
                        }
                    }
                    else {   
                        kalendarRef.rows[i].cells[j].innerHTML = dan.toString() + '<div class="slobodna">&nbsp;</div>';
                        dan++;
                    }
                }
                else if(j===prviDan){
                    for(var k=j; k<7; k++){
                        kalendarRef.rows[i].cells[k].innerHTML = dan.toString() + '<div class="slobodna">&nbsp;</div>';
                        dan++;
                    }
                    pronadjen=true;
                    break;
                }
            }
        }
    }

    function dajPrviDanUMjesecu(mjesec, godina){
        var datum = new Date(godina, mjesec, 1, 1, 1, 1, 1);
        var prviDan = datum.getDay();
        prviDan--;
        if(prviDan<0)
            prviDan=6;
        return prviDan;
    }

    function dajBrojDanaUMjesecu(mjesec, godina){
        var daniUMjesecu = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31] 
        if(((godina % 100==0) && (godina % 400==0)) || (godina % 4==0 ))
            daniUMjesecu[1]=29;
        return daniUMjesecu[mjesec];
    }
    function obojiRedovnaZauzeca(kalendarRef, dan){
        for(var i=2; i<8; i++){
            for(var j=0; j<7; j++){
                if(kalendarRef.rows[i].cells[j].innerHTML.length==36 && j==dan)
                    kalendarRef.rows[i].cells[j].innerHTML = kalendarRef.rows[i].cells[j].innerHTML.substring(0,2) + '<div class="zauzeta">&nbsp;</div>';
                else if(kalendarRef.rows[i].cells[j].innerHTML.length==35 && j==dan)
                    kalendarRef.rows[i].cells[j].innerHTML = kalendarRef.rows[i].cells[j].innerHTML.substring(0,1) + '<div class="zauzeta">&nbsp;</div>';
            }
        }
    }
    function obojiVanrednaZauzeca(kalendarRef, mjesec, danZauzeca, mjesecZauzeca){
        for(var i=2; i<8; i++){
            for(var j=0; j<7; j++){
                mjesec++;
                if(kalendarRef.rows[i].cells[j].innerHTML.length==36 && kalendarRef.rows[i].cells[j].innerHTML.substring(0,2)==danZauzeca && mjesec.toString()==mjesecZauzeca)
                    kalendarRef.rows[i].cells[j].innerHTML = kalendarRef.rows[i].cells[j].innerHTML.substring(0,2) + '<div class="zauzeta">&nbsp;</div>';
                else if(kalendarRef.rows[i].cells[j].innerHTML.length==35 && kalendarRef.rows[i].cells[j].innerHTML.substring(0,1)==danZauzeca && mjesec.toString()==mjesecZauzeca)
                    kalendarRef.rows[i].cells[j].innerHTML = kalendarRef.rows[i].cells[j].innerHTML.substring(0,1) + '<div class="zauzeta">&nbsp;</div>';
                mjesec--;
            }
        }
    }
    function poklapanjeTermina(hp, mp, hk, mk, h1, m1, h2, m2) {
        if((h1+m1===h2+m2) || h1>h2 || (h1==h2 && m1>m2))
            return false;
        if(hk==h1 && mk==m1)
            return false;
        if(hp==h2 && mp==m2)
            return false;
        if(hp<=h1 && hk>=h2)
            return true;
        return (h1 < hp || h1 == hp && m1 <= mp) && (hp < h2 || hp == h2 && mp <= m2) || (h1 < hk || h1 == hk && m1 <= mk) && (hk < h2 || hk == h2 && mk <= m2);
    }

    return {
        obojiZauzeca: obojiZauzecaImpl,
        ucitajPodatke: ucitajPodatkeImpl,
        iscrtajKalendar: iscrtajKalendarImpl
    }
}());

document.getElementById("prethodni").addEventListener("click", function(){
    if(trenutniMjesec==0)
        this.disabled = true;
    else {
        document.getElementById("sljedeci").disabled = false;
        trenutniMjesec--; 
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
        Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, trenutnaSala, trenutniPocetak, trenutniKraj);
    }
});
document.getElementById("sljedeci").addEventListener("click", function(){
    if(trenutniMjesec==11)
        this.disabled = true;
    else {
        document.getElementById("prethodni").disabled = false;
        trenutniMjesec++; 
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
        Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, trenutnaSala, trenutniPocetak, trenutniKraj);
    }
});
document.getElementById("listaSala").addEventListener("change", function(){
    trenutnaSala=this.value;
    if(trenutnaSala!="" && trenutniPocetak!="" && trenutniKraj!="")
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
    Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, trenutnaSala, trenutniPocetak, trenutniKraj);
});
document.getElementById("pocetak").addEventListener("change", function(){
    var sati = this.value.split(":")[0];
    var minute = this.value.split(":")[1];
    trenutniPocetak = sati + ":" + minute;
    if(trenutniPocetak==":")
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
    if(trenutnaSala!="" && trenutniPocetak!="" && trenutniKraj!="")
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
    Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, trenutnaSala, trenutniPocetak, trenutniKraj);
});
document.getElementById("kraj").addEventListener("change", function(){
    var sati = this.value.split(":")[0];
    var minute = this.value.split(":")[1];
    trenutniKraj = sati + ":" + minute;
    if(trenutniKraj==":")
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
    if(trenutnaSala!="" && trenutniPocetak!="" && trenutniKraj!="")
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
    Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, trenutnaSala, trenutniPocetak, trenutniKraj);
});