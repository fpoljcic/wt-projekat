var slike = [];
var trenutnaPrva=0;
var trenutnaZadnja=2;
let Pozivi = (function(){
    function ucitajZauzecaImpl() {
        try{
            var ajax = new XMLHttpRequest();
            ajax.onreadystatechange = function()
            {
                if (ajax.readyState === XMLHttpRequest.DONE) {
                    if (ajax.status === 200) {
                        Kalendar.ucitajPodatke(JSON.parse(ajax.responseText).periodicna, JSON.parse(ajax.responseText).vanredna);
                    }
                }
            };
            ajax.open("GET", "http://localhost:8080/rezervacije", true);
            ajax.send();
        }
        catch(error){
            console.log(error);
        }
    }

    function rezervisiVanredniTerminImpl(sala, pocetak, kraj, datum, predavac) {
        try{
            var ajax = new XMLHttpRequest();
            ajax.open("POST", "http://localhost:8080/rezervisiVanredno", true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.onreadystatechange = function () {
                if (ajax.readyState === 4 && ajax.status === 200) {
                    Kalendar.ucitajPodatke(JSON.parse(ajax.responseText).periodicna, JSON.parse(ajax.responseText).vanredna);
                    Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, sala, pocetak, kraj);
                }
                else if (ajax.status === 500) {
                    alert(ajax.responseText);
                }
            };
            var data = JSON.stringify({"datum": datum,"pocetak": pocetak,"kraj": kraj,"naziv": sala,"predavac": predavac});

            ajax.send(data);
        }
        catch(error){
            console.log(error);
        }
    }

    function rezervisiPeriodicneTermineImpl(sala, pocetak, kraj, datum, predavac, semestar, dan) {
        try{
            var ajax = new XMLHttpRequest();
            ajax.open("POST", "http://localhost:8080/rezervisiPeriodicne", true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.onreadystatechange = function () {
                if (ajax.readyState === 4 && ajax.status === 200) {
                    Kalendar.ucitajPodatke(JSON.parse(ajax.responseText).periodicna, JSON.parse(ajax.responseText).vanredna);
                    Kalendar.obojiZauzeca(document.getElementById("kalendar"), trenutniMjesec, sala, pocetak, kraj);
                }
                else if (ajax.status === 500) {
                    alert(ajax.responseText);
                }
            };
            var data = JSON.stringify({"dan": dan,"semestar": semestar,"pocetak": pocetak,"kraj": kraj,"naziv": sala,"predavac": predavac});

            ajax.send(data);
        }
        catch(error){
            console.log(error);
        }
    }

    function ucitajSlikeImpl(prva, zadnja) {
        try{
            var ajax = new XMLHttpRequest();
            ajax.open("POST", "http://localhost:8080/slike", true);
            ajax.setRequestHeader("Content-Type", "application/json");
            ajax.onreadystatechange = function () {
                if (ajax.readyState === 4 && ajax.status === 200) {
                    var slikeJSON = JSON.parse(ajax.responseText);
                    slikeJSON = JSON.parse(slikeJSON);
                    if(slikeJSON.url.length%3==0) {
                        slike.push(slikeJSON.url[0]);
                        slike.push(slikeJSON.url[1]);
                        slike.push(slikeJSON.url[2]);
                        document.getElementById("slika1").src = slike[slike.length-3];
                        document.getElementById("slika2").src = slike[slike.length-2];
                        document.getElementById("slika3").src = slike[slike.length-1];
                        if(slikeJSON.zadnja)
                            document.getElementById("sljedeciPocetna").disabled = true;
                    }
                    else if(slikeJSON.url.length%3==1){
                        slike.push(slikeJSON.url[0]);
                        document.getElementById("slika1").src = slike[slike.length-1];
                        document.getElementById("slika2").style.visibility = "hidden";
                        document.getElementById("slika2").src = "";
                        document.getElementById("slika3").style.visibility = "hidden";
                        document.getElementById("slika3").src = "";
                        document.getElementById("sljedeciPocetna").disabled = true;
                    }
                    else {
                        slike.push(slikeJSON.url[0]);
                        slike.push(slikeJSON.url[1]);
                        document.getElementById("slika1").src = slike[slike.length-2];
                        document.getElementById("slika2").src = slike[slike.length-1];
                        document.getElementById("slika3").style.visibility = "hidden";
                        document.getElementById("slika3").src = "";
                        document.getElementById("sljedeciPocetna").disabled = true;
                    }
                }
                else if (ajax.status === 500) {
                    alert(JSON.parse(ajax.responseText).greska);
                }
            };
            var data = JSON.stringify({"prva": prva,"zadnja": zadnja});

            ajax.send(data);
        }
        catch(error){
            console.log(error);
        }
    }

    return {
        ucitajZauzeca : ucitajZauzecaImpl,
        rezervisiVanredniTermin : rezervisiVanredniTerminImpl,
        rezervisiPeriodicneTermine : rezervisiPeriodicneTermineImpl,
        ucitajSlike : ucitajSlikeImpl
    }
}());