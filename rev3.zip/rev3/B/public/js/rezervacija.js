var kalendarRef = document.getElementById("kalendar");
if (kalendarRef != null) {
    for (var i = 2; i < kalendarRef.rows.length; i++) {
        for (var j = 0; j < kalendarRef.rows[i].cells.length; j++)
        kalendarRef.rows[i].cells[j].onclick = function () {
            rezervacijaTermina(this);
        };
    }
}

function rezervacijaTermina(dan) {
    if(trenutnaSala!="" && trenutniPocetak!="" && trenutniKraj!="") {
        if(dan.innerHTML.length==36 && dan.innerHTML.substring(2,dan.innerHTML.length) != '<div class="zauzeta">&nbsp;</div>') {
            var r = confirm("Ako želite rezervisati termin pritisnite OK!");
            if (r == true) {
                var m = trenutniMjesec+1;
                var mjesec;
                if(m<10)
                    mjesec = "0" + m.toString();
                else
                    mjesec = m.toString();
                var dan = dan.innerHTML.substring(0,2);
                var godina = d.getFullYear();
                var datum = dan + "." + mjesec + "." + godina;
                var dpom = new Date(godina, trenutniMjesec, parseInt(dan), 1, 1, 1, 1);
                var danUSedmici = dpom.getDay();
                danUSedmici--;
                if(danUSedmici<0)
                    danUSedmici=6;
                var semestar="";
                if(mjeseci[trenutniMjesec]=="Januar" || mjeseci[trenutniMjesec]=="Oktobar" || mjeseci[trenutniMjesec]=="Novembar" || mjeseci[trenutniMjesec]=="Decembar")
                    semestar="zimski";
                else if(mjeseci[trenutniMjesec]=="Februar" || mjeseci[trenutniMjesec]=="Mart" || mjeseci[trenutniMjesec]=="April" || mjeseci[trenutniMjesec]=="Maj" || mjeseci[trenutniMjesec]=="Juni")
                    semestar="ljetni";
                if(document.getElementById("periodicna").checked && semestar!="")
                    Pozivi.rezervisiPeriodicneTermine(trenutnaSala, trenutniPocetak, trenutniKraj, datum, "Šupić Haris", semestar,danUSedmici);
                else
                    Pozivi.rezervisiVanredniTermin(trenutnaSala, trenutniPocetak, trenutniKraj, datum, "Šupić Haris");
            }
        }
        else if(dan.innerHTML.length==35 && dan.innerHTML.substring(1,dan.innerHTML.length) != '<div class="zauzeta">&nbsp;</div>' && dan.innerHTML.substring(1,2) == '<') {
            var r = confirm("Ako želite rezervisati termin pritisnite OK!");
            if (r == true) {
                var m = trenutniMjesec+1;
                var mjesec;
                if(m<10)
                    mjesec = "0" + m.toString();
                else
                    mjesec = m.toString();
                var dan = "0" + dan.innerHTML.substring(0,1);
                var godina = d.getFullYear();
                var datum = dan + "." + mjesec + "." + godina;
                var dpom = new Date(godina, trenutniMjesec, parseInt(dan), 1, 1, 1, 1);
                var danUSedmici = dpom.getDay();
                danUSedmici--;
                if(danUSedmici<0)
                    danUSedmici=6;
                var semestar="";
                if(mjeseci[trenutniMjesec]=="Januar" || mjeseci[trenutniMjesec]=="Oktobar" || mjeseci[trenutniMjesec]=="Novembar" || mjeseci[trenutniMjesec]=="Decembar")
                    semestar="zimski";
                else if(mjeseci[trenutniMjesec]=="Februar" || mjeseci[trenutniMjesec]=="Mart" || mjeseci[trenutniMjesec]=="April" || mjeseci[trenutniMjesec]=="Maj" || mjeseci[trenutniMjesec]=="Juni")
                    semestar="ljetni";
                if(document.getElementById("periodicna").checked && semestar!="")
                    Pozivi.rezervisiPeriodicneTermine(trenutnaSala, trenutniPocetak, trenutniKraj, datum, "Šupić Haris", semestar,danUSedmici);
                else
                    Pozivi.rezervisiVanredniTermin(trenutnaSala, trenutniPocetak, trenutniKraj, datum, "Šupić Haris");
            }
        }
    }
    else if(dan.innerHTML.length!=0){
        alert("Nemoguće rezervisati termin, jer nisu sva polja ispravno unesena!");
    }
}

document.addEventListener("DOMContentLoaded", function() {
    Pozivi.ucitajZauzeca();
    Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
});