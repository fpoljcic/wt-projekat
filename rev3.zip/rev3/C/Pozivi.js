/*ZaAjaxpozivenapravitemodulPoziviukojemćebitimetodekojećetekoristitiusljedećimzadacima.PovezivanjemodulaPoziviiwebstraniceuraditeujsfajlukojisezovekaoistranica.Modulnapravitenaistinačinkakojepravljenmodulnaprošlojspiral */
Pozivi = (function () {
    var slike_niz = [];
    var zadnja_slika_index = 0;

     function vratiSemestar(mjesec) {
        if (mjesec == 10 || mjesec == 11 || mjesec == 12 || mjesec == 1)
            return "zimski";
        else if (mjesec == 2 || mjesec == 3 || mjesec == 4 || mjesec == 5 || mjesec == 6)
            return "ljetni";
        return "";
    }

    function ucitajJSONImpl(datoteka) {
        let xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                zauzeca = JSON.parse(xhttp.responseText);
                Kalendar.ucitajPodatke(zauzeca.periodicna, zauzeca.vanredna);
            }

        }
        xhttp.open("GET", datoteka, true);
        xhttp.send();
    }

   

    function rezervisiTerminImpl(dan, mjesec, sala, pocetak, kraj, daLiJePeriodicno) {
        var mjeseci = { Januar: 1, Februar: 2, Mart: 3, April: 4, Maj: 5, Juni: 6, Juli: 7, August: 8, Septembar: 9, Oktobar: 10, Novembar: 11, Decembar: 12 };
        var dani = { 0: "ponedeljak", 1: "utorak", 2: "srijedu", 3: "cetvrtak", 4: "petak", 5: "subotu", 6: "nedjelju" };
        let datum = new Date();
        let godina = datum.getFullYear();
        let dan_sedmice = new Date(godina, mjeseci[mjesec] - 1, dan).getDay();
        if (dan_sedmice == 0) dan_sedmice = 6;
        else dan_sedmice--;
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState == 4 && (xhttp.status == 200 || xhttp.status == 220 || xhttp.status == 221)) {
                let JSONObjekat = JSON.parse(xhttp.responseText);
                Kalendar.ucitajPodatke(JSONObjekat.periodicna, JSONObjekat.vanredna);
                var kal = document.getElementById("kalendar");
                Kalendar.iscrtajKalendar(kal, mjeseci[mjesec] - 1);
                Kalendar.obojiZauzeca(kal, mjeseci[mjesec] - 1, sala, pocetak, kraj);
                if (xhttp.status == 221)
                    alert("Nije moguće rezervisati salu " + sala + " za navedeni datum " + dan + "/" + mjeseci[mjesec] + "/" + godina + " u terminu od " + pocetak + " do " + kraj + "!");
                else if (xhttp.status == 220)
                    alert("Nije moguće rezervisati salu " + sala + " periodicno u " + dani[dan_sedmice] + ", " + vratiSemestar(mjeseci[mjesec]) + " semestar, u terminu od " + pocetak + " do " + kraj + "!");
            }
        }
        xhttp.open("POST", "rezervacija.html", true);
        xhttp.setRequestHeader("Content-Type", "application/json");
        var JSONObjekat;
        if (daLiJePeriodicno) { 
            let semestar = vratiSemestar(mjeseci[mjesec]);
            if (semestar == "") {
                alert("Nije moguće rezervisati salu " + sala + " periodicno u " + dani[dan_sedmice] + ", kada traje raspust, u terminu od " + pocetak + " do " + kraj + "!");
                return;
            }
            JSONObjekat = {
                dan: dan_sedmice, semestar: semestar, pocetak: pocetak, kraj: kraj, naziv: sala, predavac: "/"
            }
        } else {
            let datum = dan + '.' + mjeseci[mjesec] + '.' + godina;
            JSONObjekat = {
                datum: datum, pocetak: pocetak, kraj: kraj, naziv: sala, predavac: "/"
            }
        }
        xhttp.send(JSON.stringify(JSONObjekat));
    }

   

    function ucitajSlike(urlovi) {
        $("#sl1").attr("src", '/galerija/' + urlovi[0]).fadeIn();
        $("#sl2").attr("src", '/galerija/' + urlovi[1]).fadeIn();
        $("#sl3").attr("src", '/galerija/' + urlovi[2]).fadeIn();
    }

    function ucitajSliku() {
        var url = '/slike';
        $.ajax({
            url: url,
            type: "POST",
            data: { niz: slike_niz },
            dataType: "json",
            success: function (response_data_json) {
                view_data = response_data_json;
                slike_niz.push(view_data[0], view_data[1], view_data[2]);
                if(view_data.includes("Nema slika")) {
                    document.getElementById("sljedece").disabled = true;
                    zadnja_slika_index += view_data.length - 1;
                } else {
                    zadnja_slika_index += 3;
                    document.getElementById("sljedece").disabled = false;
                }
                if(slike_niz.length == 3 || zadnja_slika_index == 3) {
                    document.getElementById("prethodne").disabled = true;
                } else {
                    document.getElementById("prethodne").disabled = false;
                }
                console.log(view_data);
                ucitajSlike(view_data); 
            }
        });
    }

    function ucitajSlikeImpl(mjestoPoziva) {
        var prom = 0;
        var prom_index;

        if(zadnja_slika_index == slike_niz.length && mjestoPoziva != "prethodne") {
            ucitajSliku();
        } else if(mjestoPoziva == "prethodne") {
            document.getElementById("sljedece").disabled = false; 
            if(slike_niz.includes("Nema slika") && ((zadnja_slika_index) % 3) != 0) {
                prom = (slike_niz.length - 1) % 3;
               prom_index = prom + 1;
            } else {
                prom = 3;
               prom_index = 4;
            }
            $("#sl1").attr("src", '/galerija/' + slike_niz[zadnja_slika_index - (prom_index + 2)]).fadeIn();
            $("#sl2").attr("src", '/galerija/' + slike_niz[zadnja_slika_index - (prom_index + 1)]).fadeIn();
            $("#sl2").attr("src", '/galerija/' + slike_niz[zadnja_slika_index -prom_index]).fadeIn();
            zadnja_slika_index -= prom;
            if(zadnja_slika_index == 3)
                document.getElementById("prethodne").disabled = true;
        } else if(mjestoPoziva == "sljedece") {
            document.getElementById("prethodne").disabled = false;
            if(slike_niz.includes("Nema slika") && ((slike_niz.length - 1) - zadnja_slika_index) < 3) {
                prom = (slike_niz.length - 1) - zadnja_slika_index;
            } else {
                prom = 3;
            }
            $("#sl1").attr("src", '/galerija/' + slike_niz[zadnja_slika_index]).fadeIn();
            $("#sl2").attr("src", '/galerija/' + slike_niz[zadnja_slika_index +1]).fadeIn();
            $("#sl3").attr("src", '/galerija/' + slike_niz[zadnja_slika_index + 2]).fadeIn();
            zadnja_slika_index += prom;
            if(zadnja_slika_index % 3 != 0) 
                document.getElementById("sljedece").disabled = true; 
        }
    }

    return {
        ucitajJSON: ucitajJSONImpl,
        rezervisiTermin: rezervisiTerminImpl,
        vratiSemestar: vratiSemestar,
        ucitajSlike: ucitajSlikeImpl
    }
}());

Pozivi.ucitajJSON("zauzeca.json");