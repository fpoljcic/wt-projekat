/* Ufajluindex.js senalazi kod serverskih funkcionalnosti,u package.json setrebanalazitilistasvihpaketapotrebnihzapokretanjeindex.js*/

const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname));

app.get("/", function (req, res) {
    res.sendFile(__dirname + "/pocetna.html");
});

function vratiSemestar(mjesec) {
    if (mjesec == 10 || mjesec == 11 || mjesec == 12 || mjesec == 1)
        return "zimski";
    else if (mjesec == 2 || mjesec == 3 || mjesec == 4 || mjesec == 5 || mjesec == 6)
        return "ljetni";
    return "";
}

function presjekTermina(a, b , c, d) {
    console.log(a+"b:"+b+"pocetak2"+c+"kraj2:"+d);
    return ((a <= b && c<=d &&  c>=a && b>=c  ) || //ako a-b interval bude prije 
            (a<=b && c<=d && a>=c && d>=a)              //ako c-d interval bude prije
       );
 }



app.post("/rezervacija.html", function (req, res) {
    var body = req.body;
    var dan = body.dan;
    var mjeseci = { Januar: 1, Februar: 2, Mart: 3, April: 4, Maj: 5, Juni: 6, Juli: 7, August: 8, Septembar: 9, Oktobar: 10, Novembar: 11, Decembar: 12 };
    fs.readFile('zauzeca.json', (err, data) => {
        if (err) throw err;
        zauzecaJSON = JSON.parse(data);
        
        let poc_odb_u_ms = new Date("1970-01-01 " + body.pocetak).getTime() + 3600000;
        let kr_odb_u_ms = new Date("1970-01-01 " + body.kraj).getTime() + 3600000;
        var t = false;
        if (typeof dan !== 'undefined') {
            for (let i = 0; i < zauzecaJSON.periodicna.length; i++) {
                let poc_u_ms = new Date("1970-01-01 " + zauzecaJSON.periodicna[i].pocetak).getTime() + 3600000;
                let kr_u_ms = new Date("1970-01-01 " + zauzecaJSON.periodicna[i].kraj).getTime() + 3600000;
                if (zauzecaJSON.periodicna[i].dan == body.dan && zauzecaJSON.periodicna[i].semestar == body.semestar && zauzecaJSON.periodicna[i].naziv == body.naziv
                    && presjekTermina(poc_u_ms, kr_u_ms, poc_odb_u_ms, kr_odb_u_ms)) {
                    t = true;
                    res.statusCode = 220;
                    break;
                }
            }
            if (!t) {
                
                for (let i = 0; i < zauzecaJSON.vanredna.length; i++) {
                    let poc_u_ms = new Date("1970-01-01 " + zauzecaJSON.vanredna[i].pocetak).getTime() + 3600000;
                    let kr_u_ms = new Date("1970-01-01 " + zauzecaJSON.vanredna[i].kraj).getTime() + 3600000;
                    let datumi = zauzecaJSON.vanredna[i].datum.split(".");
                    let vanredno_dan = new Date(parseInt(datumi[2]), parseInt(datumi[1]) - 1, parseInt(datumi[0])).getDay();
                    if (vanredno_dan == 0) vanredno_dan = 6;
                    else vanredno_dan--;
                    let semestar = vratiSemestar(parseInt(datumi[1]));
                    if (zauzecaJSON.vanredna[i].naziv == body.naziv && vanredno_dan == body.dan && semestar == body.semestar
                        && presjekTermina(poc_u_ms, kr_u_ms, poc_odb_u_ms, kr_odb_u_ms)) {
                        t = true;
                        res.statusCode = 220;
                        break;
                    }
                }
            }
            if (!t) zauzecaJSON.periodicna.push(body);
        } else {
            for (let i = 0; i < zauzecaJSON.vanredna.length; i++) {
                let poc_u_ms = new Date("1970-01-01 " + zauzecaJSON.vanredna[i].pocetak).getTime() + 3600000;
                let kr_u_ms = new Date("1970-01-01 " + zauzecaJSON.vanredna[i].kraj).getTime() + 3600000;
                if (zauzecaJSON.vanredna[i].datum == body.datum && zauzecaJSON.vanredna[i].naziv == body.naziv
                    && presjekTermina(poc_u_ms, kr_u_ms, poc_odb_u_ms, kr_odb_u_ms)) {
                    t = true;
                    res.statusCode = 221;
                    break;
                }
            }
            if (!t) {
                let datumi = body.datum.split(".");
                let vanredno_dan = new Date(parseInt(datumi[2]), parseInt(datumi[1]) - 1, parseInt(datumi[0])).getDay();
                if (vanredno_dan == 0) vanredno_dan = 6;
                else vanredno_dan--;
                let semestar = vratiSemestar(parseInt(datumi[1]));
          
                for (let i = 0; i < zauzecaJSON.periodicna.length; i++) {
                    let poc_u_ms = new Date("1970-01-01 " + zauzecaJSON.periodicna[i].pocetak).getTime() + 3600000;
                    let kr_u_ms = new Date("1970-01-01 " + zauzecaJSON.periodicna[i].kraj).getTime() + 3600000;
                    if (zauzecaJSON.periodicna[i].dan == vanredno_dan && semestar == zauzecaJSON.periodicna[i].semestar && zauzecaJSON.periodicna[i].naziv == body.naziv
                        && presjekTermina(poc_u_ms, kr_u_ms, poc_odb_u_ms, kr_odb_u_ms)) {
                        t = true;
                        res.statusCode = 221;
                        break;
                    }
                }
            }
            if (!t) zauzecaJSON.vanredna.push(body);
        }
        if (!t) {
            fs.writeFile('zauzeca.json', JSON.stringify(zauzecaJSON), function (err) {
                if (err) throw err;
            })
        }
        res.json(zauzecaJSON);
    })
});

app.post("/slike", function (req, res) {
    var body = req.body;
    var odgovorJSON = [];
    fs.readdir(__dirname + "/galerija", function (err, postojece_slike) {
        if (Object.entries(body).length === 0 && body.constructor === Object) { 
            odgovorJSON.push(postojece_slike[0], postojece_slike[1], postojece_slike[2]);
            res.json(odgovorJSON);
            return;
        }
        for (var i = 0; i < postojece_slike.length; i++) {
            if (!body.niz.includes(postojece_slike[i])) {
                odgovorJSON.push(postojece_slike[i]);
                if (odgovorJSON.length == 3) 
                    break;
            } 
        }
        if (postojece_slike.length - body.niz.length <= 3) {
            odgovorJSON.push("Nema slika");
        }

        res.json(odgovorJSON);
    });
});

app.listen(8080);