
let Kalendar = (function(){     
    var periodicnaZauzeca= [];
    var vanrednaZauzeca= [];
    function prviDanMjeseca(godina,mjesec){
        var dan= new Date(godina, mjesec, 1).getDay();
        if(dan == 0) dan = 7;
        return dan; 
    }
    function brojDanaMjeseca(godina,mjesec){

       return new Date(godina, mjesec, 0).getDate(); 
    }
    function presjekTermina(a, b , c, d) {
      console.log(a+"b:"+b+"pocetak2"+c+"kraj2:"+d);
      return ((a <= b && c<=d &&  c>=a && b>=c  ) || //ako a-b interval bude prije 
              (a<=b && c<=d && a>=c && d>=a)              //ako c-d interval bude prije
         );
   }
     function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj){        
      let tabeledan = kalendarRef.getElementsByClassName("dan"); 
             
      var datum = new Date();
      var godina = datum.getFullYear();
      
      let pocetno_u_ms = new Date("1970-01-01 " + pocetak).getTime() + 3600000;
      let krajnje_u_ms = new Date("1970-01-01 " + kraj).getTime() + 3600000;
      console.log(krajnje_u_ms);
      for(let i = 0; i < periodicnaZauzeca.length; i++) {
          let pocetno_u_ms_periodicno = new Date("1970-01-01 " + periodicnaZauzeca[i].pocetak).getTime() + 3600000;
          let krajnje_u_ms_periodicno= new Date("1970-01-01 " + periodicnaZauzeca[i].kraj).getTime() + 3600000;
          if(sala == periodicnaZauzeca[i].naziv && presjekTermina(pocetno_u_ms_periodicno, krajnje_u_ms_periodicno, pocetno_u_ms, krajnje_u_ms)) {
              let prviDan = prviDanMjeseca(godina,mjesec) - 1;
              let t=-1;
              if(periodicnaZauzeca[i].dan >= prviDan) t =  periodicnaZauzeca[i].dan - prviDan;
              else  t = 7 - (prviDan - periodicnaZauzeca[i].dan);
              if(periodicnaZauzeca[i].semestar == "zimski" && ((mjesec>=9 && mjesec<=11) || mjesec==0)) {
                  
                  for(let i = t; i < brojDanaMjeseca(mjesec + 1, godina); i +=7) {
                      tabeledan[i].getElementsByTagName("td").item(1).classList.remove("slobodna");
                      tabeledan[i].getElementsByTagName("td").item(1).classList.add("zauzeta");
                  }

              } else if(periodicnaZauzeca[i].semestar == "ljetni" && (mjesec>=1 && mjesec<=5)) {
                  for(let i = t; i < brojDanaMjeseca(mjesec + 1, godina); i +=7) {
                      tabeledan[i].getElementsByTagName("td").item(1).classList.remove("slobodna");
                      tabeledan[i].getElementsByTagName("td").item(1).classList.add("zauzeta");
                  }
              }
            
          } 
      }
       
      for(let i = 0; i < vanrednaZauzeca.length; i++) { 
        let pocetno_u_ms_vanredno = new Date("1970-01-01 " + vanrednaZauzeca[i].pocetak).getTime() + 3600000;
        let krajnje_u_ms_vanredno = new Date("1970-01-01 " + vanrednaZauzeca[i].kraj).getTime() + 3600000;
         let dstr = vanrednaZauzeca[i].datum.split(".");
         let dan_br = parseInt(dstr[0]);
         let mjesec_br = parseInt(dstr[1]) - 1;
         let godina_br = parseInt(dstr[2]);
         if(vanrednaZauzeca[i].naziv == sala && mjesec == mjesec_br && godina_br == godina && presjekTermina(pocetno_u_ms_vanredno, krajnje_u_ms_vanredno, pocetno_u_ms, krajnje_u_ms)) {
          tabeledan[dan_br - 1].getElementsByTagName("td").item(1).classList.remove("slobodna");
          tabeledan[dan_br- 1].getElementsByTagName("td").item(1).classList.add("zauzeta");
         }
      } 
        }    
      function ucitajPodatkeImpl(periodicna,vanredna){
          periodicnaZauzeca=periodicna;
          vanrednaZauzeca=vanredna; 
        }  
    
      function iscrtajKalendarImpl(kalendarRef,mjesec){  
        var godina =new Date().getFullYear();
        mjeseciUGodini=["Januar", "Februar", "Mart", "April", "Maj", "Juni", "Juli", "August", "Septembar", "Oktobar", "Novembar", "Decembar"];
        //naziv mjeseca trenutnog
        sadrzaj='<header id="mjesec"><h4>'+mjeseciUGodini[mjesec]+'</h4></header>';
        //dani u sedmici
        sadrzaj+="<table class=\"unutrasnja\" ><tr><td class=\"naziv\">PON</td><td class=\"naziv\">UTO</td> <td class=\"naziv\">SRI</td><td class=\"naziv\">ČET</td><td class=\"naziv\">PET</td><td class=\"naziv\">SUB</td><td class=\"naziv\">NED</td></tr>";
       //prva sedmica zbog ispod 600px
        var pd=prviDanMjeseca(godina,mjesec);
        var brDana=brojDanaMjeseca(godina,mjesec+1);
        
        sadrzaj+="<tr>"
        for(i=0;i<pd;i++){
          sadrzaj+='<td class="nema"></td>';
        }
        for(i=0;i<7-pd;i++){
          sadrzaj+='<td> <table class="dan"> <tr> <td class="broj">'+(i+1)+'</td> </tr> <tr> <td class="slobodna"></td></tr></table> </td>';
        }
        sadrzaj+="</tr>";
        var br=7-pd+1;
        for(i=0;;i++){
          sadrzaj+='<tr class="nije">';
          if(br>brDana) break;
          for(j=0;j<7;j++){
           if(br>brDana) break;
           sadrzaj+='<td > <table class="dan"> <tr> <td class="broj">'+br+'</td> </tr> <tr> <td class="slobodna"></td></tr></table> </td>';
          br++;
          }
          sadrzaj+='</tr>' 
        }

        sadrzaj+="</table>"
        //console.log(sadrzaj);
        kalendarRef.innerHTML=sadrzaj;
        }  
      return {       
           obojiZauzeca: obojiZauzecaImpl,      
             ucitajPodatke: ucitajPodatkeImpl,       
              iscrtajKalendar: iscrtajKalendarImpl   
             }
        }()); 
        
        function getUneseneVrijednosti() {
          izabraniMjesec= document.getElementById("mjesec").textContent;
          sala = document.getElementById("listaSala").value;
          pocetak = document.getElementById("pocetak").value;
          kraj = document.getElementById("kraj").value;
      }
        var mjeseci = {Januar:0, Februar:1, Mart:2, April:3, Maj:4, Juni:5, Juli:6, August:7, Septembar:8, Oktobar:9, Novembar:10, Decembar:11};
        //hardkodirane vrijednosti
        var periodicna = [{dan: 5, semestar: "zimski", pocetak: "9:00", kraj: "11:00", naziv: "MA", predavac: "Dzenana"},
                          {dan: 1, semestar: "ljetni", pocetak: "12:00", kraj: "15:00", naziv: "0-01", predavac: "Rijad"}];

       var vanredna = [{datum: "28.2.2019", pocetak: "10:00", kraj: "12:00", naziv: "VA1", predavac: "Zenan"},
                        {datum: "30.11.2019", pocetak: "15:00", kraj: "17:30", naziv: "1-03", predavac: "Emina"}];
            

        Kalendar.ucitajPodatke(periodicna,vanredna);   

        //iscrtavanje za trenutni mjesec pri otvaranju stranice 
        var trenutniMjesec=new Date().getMonth();
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"),trenutniMjesec);
        
        //promjena vrijednosti koje korisnik unosi
        document.getElementById("vrijednosti").addEventListener('change', function(event){
          Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
           //da dobijemo trenutni IZABRANI pocetak i kraj 
          getUneseneVrijednosti();
          Kalendar.obojiZauzeca(document.getElementById("kalendar"), mjeseci[mjesec], sala, pocetak, kraj);
      });
      

        document.getElementById("btn1").addEventListener("click", function() {
        document.getElementById("btn2").disabled = false;
        if(trenutniMjesec == 1)
            document.getElementById("btn1").disabled = true;
        if(trenutniMjesec != 0) 
            trenutniMjesec--;
        Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
        //da dobijemo trenutni IZABRANI mjesec
        getUneseneVrijednosti();
        Kalendar.obojiZauzeca(document.getElementById("kalendar"), mjeseci[izabraniMjesec], sala, pocetak, kraj);

   
        });

        document.getElementById("btn2").addEventListener("click", function() {
          document.getElementById("btn1").disabled = false;
          if(trenutniMjesec == 10)
              document.getElementById("btn2").disabled = true;
          if(trenutniMjesec != 11) 
              trenutniMjesec++;
          Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);
             //da dobijemo trenutni IZABRANI mjesec
        getUneseneVrijednosti();
        Kalendar.obojiZauzeca(document.getElementById("kalendar"), mjeseci[izabraniMjesec], sala, pocetak, kraj);

      });
    