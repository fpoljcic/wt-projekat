Pozivi.ucitajSlike();

function prethodneKliknuto() {
    Pozivi.ucitajSlike("prethodne");
}

function sljedeceKliknuto() {
    Pozivi.ucitajSlike("sljedece");
}