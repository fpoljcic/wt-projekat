Pozivi.ucitajJSON("zauzeca.json");


window.onclick = e => {
    console.log("u onclick metodi, target:"+e.target.className);
    if (e.target.className == "broj" || e.target.className == "slobodna" || e.target.className == "zauzeta") {
      console.log("uslo u dane");
        var conf_win = confirm("Odabrali ste rezervaciju, da li zelite nastaviti?");
        if (conf_win == true) {
            var dan, mjesec, sala, pocetak, kraj, period;
            console.log("ovo je ime: "+e.target.parentNode.parentNode.parentNode.className);
            mjesec = document.getElementById("mjesec").textContent;
            dan = e.target.parentNode.parentNode.parentNode.getElementsByClassName("broj").item(0).innerText;
            sala = document.getElementById("sale").value;
            pocetak = document.getElementById("pocetak").value;
            kraj = document.getElementById("kraj").value;
            
            period = document.getElementById("period").checked;
            if (e.target.parentNode.parentNode.parentNode.getElementsByTagName("td").item(1).className == "zauzeta") {
                var mjeseci = { Januar: 0, Februar: 1, Mart: 2, April: 3, Maj: 4, Juni: 5, Juli: 6, August: 7, Septembar: 8, Oktobar: 9, Novembar: 10, Decembar: 11 };
                var dani = { 0: "ponedeljak", 1: "utorak", 2: "srijedu", 3: "cetvrtak", 4: "petak", 5: "subotu", 6: "nedjelju" };
                var datum = new Date();
                var godina = datum.getFullYear();
                var dan_sedmice = new Date(godina, mjeseci[mjesec], dan).getDay();
                if (dan_sedmice == 0) dan_sedmice = 6;
                else dan_sedmice--;
                if (!period) 
                    alert("Nije moguce rezervisati salu " + sala + " za navedeni datum " + e.target.parentNode.parentNode.parentNode.getElementsByClassName("broj").item(0).innerText +
                        "/" + (mjeseci[mjesec] + 1) + "/" + godina + " u terminu od " + pocetak + " do " + kraj + "!");
                else {
                    var semestar = Pozivi.dajSemestar(mjeseci[mjesec] + 1) + " semestar";
                    if(semestar == " semestar") 
                        semestar = "za vrijeme raspusta";
                    alert("Nije moguće rezervisati salu " + sala + " periodicno u " + dani[dan_sedmice] + ", " + sem + ",  termin: od " + pocetak + " do " + kraj + "!");
                }
            } else {
                Pozivi.rezervisiTermin(dan, mjesec, sala, pocetak, kraj, period);
            }
        } else {

        }
    }
};



