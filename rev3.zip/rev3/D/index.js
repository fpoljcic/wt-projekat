const express = require('express');
const app = express();

const fs = require('fs')

const bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//Fajlovi koji su static (jer je zadato da je neki direktorij static, pa su tako i svi fajlovi u njemu sttaic) su fajlovi koje klijenti 
//zahtijevaju (salju requestove za njih) od servera.
//Treba napraviti neki folder unutar kojeg ce se staviti svi fajlovi kao sto su slike, css-ovi, html-ovi, js-ovi...
//Izvrsavanjem naredbe "app.use(express.static('publicFajlovi'));" govorimo programu u kojem direktoriju se nalaze 
//staticki fajlovi, pri cemu se ovo moze iskoristi umjesto pisanja "app.get()" za sve fajlove, jer ce to u ovom slucaju 
//biti odradjeno za nas u pozadini (ne is ostalih metoda)
//BITNO- nakon deklarisanja statickog direktorija, Express trazi fajlove relativno od tog statickog direktorija (s tim da ime smaog statickog 
//direkorija ne ulazi u URL)!!! ---> ovo je isti princip na kojem smo radili nginx-om na Spirali 2 
app.use(express.static('publicFajlovi'));

//svi get requestovi se automatski generisu na osonvu pravljenja statickog folderalinijom iznad, ali
// request ukoliko se posaljes amo na "localhost:BROJ_PORTA" pise u postavci da se treba prikazati pocetna.html
app.get('/', function(request, response)
{
    response.sendFile(__dirname+"/publicFajlovi/html/pocetna5.html");
});

app.post('/publicFajlovi/zauzeca.json', function(request, response)
{
    //"req.body" - dobavlja tijelo zahtijeva se u expressu  
    let tijeloPOSTrequesta = request.body;
    
    //iako se salje kao broj atribut "dan", ajax ga prebasi u string, pa ga je potrebno ponovno prebaciti u broj
    if(tijeloPOSTrequesta.dan)
        tijeloPOSTrequesta.dan = Number(tijeloPOSTrequesta.dan);
    
   fs.readFile(__dirname+'/publicFajlovi/zauzeca.json', function(err, buffer)
   {
        if(err) 
            throw err;

        let objekat = JSON.parse(buffer);

        if(tijeloPOSTrequesta['datum'])
            objekat.vanredna.push(tijeloPOSTrequesta);
        else
            objekat.periodicna.push(tijeloPOSTrequesta);

         //"JSON.stringify(objekt)" funckija pretvara objekt u string koji je json formata
        fs.writeFile(__dirname+'/publicFajlovi/zauzeca.json', JSON.stringify(objekat), function(err){
                if(err) 
                    throw err;
        })
        
        response.json(objekat);
   });
});

const MAX_BROJ_SLIKA_KOJE_SE_UCITAVAJU = 3;

/*app.get("/publicFajlovi/slike", function(request, response)
{
    let tijeloPOSTrequesta = request.body;
    let nizVecProcitanihSlika = tijeloPOSTrequesta.nizVecProcitanihSlika;

    let sveSlikeIzFoldera = fs.readdirSync(__dirname+"/publicFajlovi/slike");
    
    console.log("sveSlikeIzFoldera:\n");
    console.log(sveSlikeIzFoldera);
    
    let noveNeprocitaneSlike = [];

    for(let i=0; i<sveSlikeIzFoldera.length; i++)
    {
        if(nizVecProcitanihSlika.includes(sveSlikeIzFoldera[i]) == false)
        {
            noveNeprocitaneSlike.push(sveSlikeIzFoldera[i]);

            if(noveNeprocitaneSlike.length == MAX_BROJ_SLIKA_KOJE_SE_UCITAVAJU)
                break;
        }
    }

    response.json(noveNeprocitaneSlike);
});*/

/*app.post('/publicFajlovi/slike/slika1.jpg', function(request, response)
{
    console.log("uspjesno usao u POST metodu za slike!!!");

    let tijeloPOSTrequesta = request.body;
    
    let nizVecProcitanihSlika = tijeloPOSTrequesta.nizVecProcitanihSlika;

    let sveSlikeIzFoldera = fs.readdirSync(__dirname+"/publicFajlovi/slike");
    
    console.log("sveSlikeIzFoldera:\n");
    console.log(sveSlikeIzFoldera);
    
    let noveNeprocitaneSlike = [];

    for(let i=0; i<sveSlikeIzFoldera.length; i++)
    {
        if(nizVecProcitanihSlika.includes(sveSlikeIzFoldera[i]) == false)
        {
            noveNeprocitaneSlike.push(sveSlikeIzFoldera[i]);

            if(noveNeprocitaneSlike.length == MAX_BROJ_SLIKA_KOJE_SE_UCITAVAJU)
                break;
        }
    }

    response.json(noveNeprocitaneSlike);
});*/
app.post('/slike', function(request, response)
{
    console.log("uspjesno usao u POST metodu za slike!!!");

    let tijeloPOSTrequesta = request.body;

    let sveSlikeIzFoldera = fs.readdirSync(__dirname+"/publicFajlovi/slike");
    
    console.log("sveSlikeIzFoldera:\n");
    console.log(sveSlikeIzFoldera);
    
    let noveNeprocitaneSlike = [];
    let sveUcitaneSlike = false;
    for(let i=0; i<sveSlikeIzFoldera.length; i++)
    {
        if(tijeloPOSTrequesta.includes(sveSlikeIzFoldera[i]) == false)
        {
            noveNeprocitaneSlike.push(sveSlikeIzFoldera[i]);

            if(noveNeprocitaneSlike.length == MAX_BROJ_SLIKA_KOJE_SE_UCITAVAJU)
            {
                if(sveSlikeIzFoldera.length-1 == i)
                    sveUcitaneSlike = true;

                break;
            }
        }
    }

    if(noveNeprocitaneSlike.length < 3 || sveUcitaneSlike==true)
        noveNeprocitaneSlike.push("nema vise novih slika");
    
    response.json(noveNeprocitaneSlike);
});

app.listen(8080);
