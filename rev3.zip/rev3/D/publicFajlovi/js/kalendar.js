var korisnikGledaGodinu = new Date().getFullYear();
var korisnikGledaMjesec = new Date().getMonth();

let Kalendar = (function()
{	
	//GLOBALNE VARIJABLE
	var nizRedovnihZauzeca = [];
	var nizVanrednihZauzeca = []; 

	function iscrtajKalendarImpl(kalendarRef, mjesec)
	{
		korisnikGledaMjesec = mjesec;
		
		//var mjesec = new Date().getMonth();
		
		//'uvijek popunjavate dane na osnovu trenutne godine. Možete korisiti "Date()" objekat'
		//var trenutniDatumiVrijeme = new Date(); //  npr: Sun Nov 17 2019 19:49:52 GMT+0100 (Central European Standard Time)
		//var trenutnaGodina = trenutniDatumiVrijeme.getFullYear(); // 'yyyy'
		//var trenutniMjesec = trenutniDatumiVrijeme.getMonth(); // od 0 do 11
		//var trenutniDanUMjesecu = trenutniDatumiVrijeme.getDate(); // od 1 do 31
		//var trenutniDanuSedmici = trenutniDatumiVrijeme.getDay(); // od 0 do 6
		
		//getDate vraca redni broj dana u mjesecu
		//https://stackoverflow.com/questions/43182667/why-does-javascript-new-dateyear-month-0-getdate-return-the-number-of-day
		var brojDanaUOvomMjesecu = new Date(korisnikGledaGodinu, korisnikGledaMjesec+1, 0).getDate();
		
		var nizDanauSedmici = ["PON", "UTO", "SRI", "ČET", "PET", "SUB", "NED"];
		
		var nizMjeseciuGodini = ["Januar", "Februar", "Mart", "April", "Maj", "Juni", "Juli", "August", "Septembar",
								 "Oktobar", "Novembar", "Decembar"];
								 
		console.log("korisninik gleda "+korisnikGledaGodinu+" godinu i "+nizMjeseciuGodini[korisnikGledaMjesec]+" mjesec, i on ima "+brojDanaUOvomMjesecu+"");
		
		/*elemnti se u ovom nizu pojavljuju u redoslijedu kojim su napisani u js fajlu*/
		/*You can use the length property of the NodeList object to determine the number 
		of elements with a specified class name, then you can loop through all elements 
		and extract the info you want.*/
		var nizElemenataSaKlasomKalendarTabela = document.getElementsByClassName("kalendarTabela");
		
		var innerText = "<tr class=\"prviRed\">"
							+"<td class=\"celijaTabele nazivMjeseca\" colspan=\"7\">"
								+ nizMjeseciuGodini[korisnikGledaMjesec] + " ("+korisnikGledaGodinu+". godine)"
							+"</td>"
						+"</tr>"
							+"<tr class=\"red\">"
								+"<td class=\"celijaTabele nazivDana\">pon</td>"
								+"<td class=\"celijaTabele nazivDana\">uto</td>"
								+"<td class=\"celijaTabele nazivDana\">sri</td>"
								+"<td class=\"celijaTabele nazivDana\">čet</td>"
								+"<td class=\"celijaTabele nazivDana\">pet</td>"
								+"<td class=\"celijaTabele nazivDana\">sub</td>"
								+"<td class=\"celijaTabele nazivDana\">ned</td>"
							+"</tr>";
		
		var nizSedmica =["prvaSedmica", "drugaSedmica", "trecaSedmica", "cetvrtaSedmica", "petaSedmica", "sestaSedmica"];
		
		let kojiDanJePrviUMjesecu = dajPrviDanUMjesecu(korisnikGledaGodinu, korisnikGledaMjesec);
		
		var brojRedovaTable = 6;
		if(kojiDanJePrviUMjesecu <= 4) //ako je prvi u mjesecu subota ili nedjelja treba 6 redova, a ako ne, onda 5
					brojRedovaTable = 5;
					
		for (let i = 0; i < brojRedovaTable; i++) // maksimalno redova u tabeli kalendara (ne racunajuci prvi red s imenima)
		{
			innerText += "<tr class=\" red "+nizSedmica[i]+"\">";
			
			let j = 0;
			if( i==0 )
			{
				//Petlja koja stavlja na poecteku kalendara prazne, prozirne celije. Ide do 5 maksimalno, tj. sestog dana u sedmici, 
				// a ne sedmog, jer prvi dan u mjesecu mora biti u jendom od sedam dana.
				for(; j < kojiDanJePrviUMjesecu; j++)
					innerText += "<td class=\"praznaCelijaTabele\"></td>";
			}
			
			var brojKolona = 7;
			for(; j < brojKolona; j++)
			{
				let datum = i*7 + j - kojiDanJePrviUMjesecu + 1;  
				
				if(datum <= brojDanaUOvomMjesecu)
				{
					let danasnjiDatum = new Date();
					if(danasnjiDatum.getFullYear() == korisnikGledaGodinu && danasnjiDatum.getMonth() == korisnikGledaMjesec 
						&& danasnjiDatum.getDate() == datum)
					{
						//boldiranje danasnjeg datuma u kalendaru
							innerText += "<td class=\"celijaTabele\">"
								+"<div class=\"prviDioCelije\" style=\"background-color:rgb(165, 165, 165);\"><b>"+datum+"<b></div>" ;
					}
					else
					{
						innerText += "<td class=\"celijaTabele\">"
									+"<div class=\"prviDioCelije\">"+datum+"</div>" ;
					}
							  
					//3 numbers specify year, month, and day: Example var d = new Date(2018, 11, 24);	
					/*DA SVI DATUMI PRIJE DANASNJEG BUDU OZNACENI SA CRVENOM BOJOM, TJ. KAO DA SU ZAUZETI, OTKOMENTARISATI OVAJ DIO KODA 
					if( jeLiOvajDanPrijeDanas(new Date(korisnikGledaGodinu, korisnikGledaMjesec, datum)) === true) 
						innerText += "<div class=\"drugiDioCelijeZauzeta\"></div>";
					else*/
						innerText += "<div class=\"drugiDioCelijeSlobodna\"></div>";
				
					innerText += "</td>";
				}
				else
				{
					innerText += "<td class=\"praznaCelijaTabele\"></td>";
				}				
			}	
		
			innerText += "</tr>";
		}
		
		kalendarRef.innerHTML = innerText; 
	}

	function jeLiOvajDanPrijeDanas(datumKojiSeIspituje)
	{
		return (datumKojiSeIspituje < new Date());
	}
	
	function dajPrviDanUMjesecu(godina, mjesec)
	{
		let kojiDanJePrviUMjesecu = new Date(godina, mjesec,1).getDay();
		
		//ZATO STO SU DEFAULTNO POREDANI, nedjelja, pon, uto... DOK JE U KALENDARU pon, uto, sri...
		if(kojiDanJePrviUMjesecu == 0)
			kojiDanJePrviUMjesecu = 6;
		else
			kojiDanJePrviUMjesecu -= 1; 
		
		return kojiDanJePrviUMjesecu;
	}

	function ucitajPodatkeImpl(redovna, vanredna)
	{
		if(validniPodaciKojiSeUcitavaju(vanredna, redovna)==true)
		{
			nizRedovnihZauzeca = redovna;
			nizVanrednihZauzeca = vanredna;
		}
		else
			console.log("prosljedjeni podaci nisu validni, ignorisu se");
	}
	
	function validniPodaciKojiSeUcitavaju(vanredna, redovna)
	{
		//VALIDACIJA ZA REDOVNA ZAUZECA
		for(let i=0; i<redovna.length; i++)
		{
			if(redovna[i].dan==null || isNaN(redovna[i].dan) || (redovna[i].dan<0 || redovna[i].dan>6))
				return false;
			
			if(redovna[i].semestar==null || (redovna[i].semestar!="zimski" && redovna[i].semestar!="ljetni"))
				return false;
			//------------------------------------------
			if(redovna[i].pocetak==null)
				return false;
			
			let vrijemePocetak = redovna[i].pocetak.split(':');
			
			//isNaN(num)         // returns true if the variable does NOT contain a valid number
			if(vrijemePocetak.length!=2 || isNaN(vrijemePocetak[0]) || isNaN(vrijemePocetak[1]))
				return false;
			
			let satiPocetak = parseInt(vrijemePocetak[0]);
			let minutePocetak = parseInt(vrijemePocetak[1]);
			
			if(satiPocetak<0 || satiPocetak>24)
				return false;
			
			if(minutePocetak<0 || minutePocetak>=60)
				return false;
			//------------------------------------------
			if(redovna[i].kraj==null)
				return false;
			
			let vrijemeKraj = redovna[i].kraj.split(':');
			
			//isNaN(num)         // returns true if the variable does NOT contain a valid number
			if(vrijemeKraj.length!=2 || isNaN(vrijemeKraj[0]) || isNaN(vrijemeKraj[1]))
				return false;
			
			let satiKraj = parseInt(vrijemeKraj[0]);
			let minuteKraj = parseInt(vrijemeKraj[1]);
			
			if(satiKraj<0 || satiKraj>24)
				return false;
			
			if(minuteKraj<0 || minuteKraj>=60)
				return false;
			//------------------------------------------
			let vrijemePocetkaUMinutama = parseInt( vrijemePocetak[0] * 60 + vrijemePocetak[1]);
			let vrijemeKrajaUMinutama = parseInt( vrijemeKraj[0] * 60 + vrijemeKraj[1]);
			
			if(vrijemeKrajaUMinutama <= vrijemePocetkaUMinutama)
				return false;
		}
		
		//VALIDACIJA ZA VANREDNA ZAUZECA
		for(let i=0; i<vanredna.length; i++)
		{
			if(vanredna[i].datum==null)
				return false;
			
			let datum = vanredna[i].datum.split('.');
			
			if(datum== null || datum.length!=3 || isNaN(datum[0]) || isNaN(datum[1]) || isNaN(datum[2]))
					return false;
				
			let dan = parseInt(datum[0]);
			let mjesec = parseInt(datum[1])-1;
			let godina = parseInt(datum[2]);
			
			if(dan<0 || dan>31 || mjesec<0 || mjesec>11)
				return false;
			
			//------------------------------------------
			if(vanredna[i].pocetak==null)
				return false;
			
			let vrijemePocetak = vanredna[i].pocetak.split(':');
			
			//isNaN(num)         // returns true if the variable does NOT contain a valid number
			if(vrijemePocetak.length!=2 || isNaN(vrijemePocetak[0]) || isNaN(vrijemePocetak[1]))
				return false;
			
			let satiPocetak = parseInt(vrijemePocetak[0]);
			let minutePocetak = parseInt(vrijemePocetak[1]);
			
			if(satiPocetak<0 || satiPocetak>24)
				return false;
			
			if(minutePocetak<0 || minutePocetak>=60)
				return false;
			//------------------------------------------
			if(vanredna[i].kraj==null)
				return false;
			
			let vrijemeKraj = vanredna[i].kraj.split(':');
			
			//isNaN(num)         // returns true if the variable does NOT contain a valid number
			if(vrijemeKraj.length!=2 || isNaN(vrijemeKraj[0]) || isNaN(vrijemeKraj[1]))
				return false;
			
			let satiKraj = parseInt(vrijemeKraj[0]);
			let minuteKraj = parseInt(vrijemeKraj[1]);
			
			if(satiKraj<0 || satiKraj>24)
				return false;
			
			if(minuteKraj<0 || minuteKraj>=60)
				return false;
			//------------------------------------------
			let vrijemePocetkaUMinutama = parseInt( vrijemePocetak[0] * 60 + vrijemePocetak[1] );
			let vrijemeKrajaUMinutama = parseInt( vrijemeKraj[0] * 60 + vrijemeKraj[1] );
			
			if(vrijemeKrajaUMinutama <= vrijemePocetkaUMinutama)
				return false;
		}
				
		return true;
		/*REDOVNA
		{
			dan: broj od 0-6 koji redom predstavlja ponedjeljak do petka,
			semestar: “zimski” ili “ljetni”,
			pocetak: string u formatu “hh:mm”,
			kraj: string u formatu “hh:mm”,
			naziv: string,
			predavac: string
		}
		VANREDNA
		{
			datum: string u formatu “dd.mm.yyyy”,
			pocetak: string u formatu “hh:mm”,
			kraj: string u formatu “hh:mm”,
			naziv: string,
			predavac: string
		}*/
	}

	function obojiZauzecaImpl(kalendarRef, mjesec, sala, vrijemePocetka, vrijemeKraja)
	{
		iscrtajKalendarImpl(kalendarRef, mjesec);
		
		// "kalendarRef" je HTML element kojeg trebas obojiti
		let nizNepraznihCelijaTabele = kalendarRef.querySelectorAll('td.celijaTabele:not(.nazivDana):not(.nazivMjeseca)');
		
		//za REDOVNA zauzeca
		for(let i=0; i<nizRedovnihZauzeca.length; i++)
		{
			//ako je atribut "mjesec", 9(oktobar), 10(novembar), 11(decembar), ili 0(januar) - onda polje "semestar", clana niza "nizRedovnihZauzeca", mora biti 'zimski'
			if( (mjesec == 9 || mjesec == 10 || mjesec == 11 || mjesec == 0) && nizRedovnihZauzeca[i].semestar == "zimski")
			{	
				if(daLiSePoklapajuIntervali(vrijemePocetka, vrijemeKraja, nizRedovnihZauzeca[i].pocetak, nizRedovnihZauzeca[i].kraj) && sala == nizRedovnihZauzeca[i].naziv)
				{
					//ako su se ulazni parametri poklopili na osnovu 4 atributa, sa 4 polja niza "nizRedovnihZauzeca", onda bojimo kao zauzeto polje u kalendaru
					// svaki dan koji odgovara polju "dan" unutar jedanog clana niza "nizRedovnihZauzeca"
					
					let danKojiJeRedovnoZauzetUMjesecu = nizRedovnihZauzeca[i].dan;
					let danKojiJePrviUmjesecu = dajPrviDanUMjesecu(korisnikGledaGodinu, mjesec);
					
					//ODREDJIVANJE BROJA REDOVA TABELE
					let j=0;
					
					if(danKojiJeRedovnoZauzetUMjesecu < danKojiJePrviUmjesecu)
						j = (7 - danKojiJePrviUmjesecu) + danKojiJeRedovnoZauzetUMjesecu;
					else
						j = danKojiJeRedovnoZauzetUMjesecu - danKojiJePrviUmjesecu;
					
					for(j; j<nizNepraznihCelijaTabele.length; j+=7)
					{		
						let innerText = "<div class=\"prviDioCelije\">"+(j+1)+"</div>"
									  + "<div class=\"drugiDioCelijeZauzeta\" style=\"background-color: rgb(255, 169, 169)\"></div>";
							
						nizNepraznihCelijaTabele[j].innerHTML = innerText;
					}
				}
				
			}
			else if( (mjesec == 1 || mjesec == 2 || mjesec == 3 || mjesec == 4 
				|| mjesec == 5) && nizRedovnihZauzeca[i].semestar == "ljetni")
			{
				// --II--, onda polje "semestar", clana niza "nizRedovnihZauzeca", mora biti 'ljetni'
				
				if(daLiSePoklapajuIntervali(vrijemePocetka, vrijemeKraja, nizRedovnihZauzeca[i].pocetak, 
					nizRedovnihZauzeca[i].kraj) && sala == nizRedovnihZauzeca[i].naziv)
				{
					//ako su se ulazni parametri poklopili na osnovu 4 atributa, sa 4 polja niza "nizRedovnihZauzeca", onda bojimo kao zauzeto polje u kalendaru
					// svaki dan koji odgovara polju "dan" unutar jedanog clana niza "nizRedovnihZauzeca"
					
					let danKojiJeRedovnoZauzetUMjesecu = nizRedovnihZauzeca[i].dan;
					let danKojiJePrviUmjesecu = dajPrviDanUMjesecu(korisnikGledaGodinu, mjesec);
					
					//ODREDJIVANJE BROJA REDOVA TABELE
					let j=0;
					
					if(danKojiJeRedovnoZauzetUMjesecu < danKojiJePrviUmjesecu)
						j = (7 - danKojiJePrviUmjesecu) + danKojiJeRedovnoZauzetUMjesecu;
					else
						j = danKojiJeRedovnoZauzetUMjesecu - danKojiJePrviUmjesecu;
					
					for(j; j<nizNepraznihCelijaTabele.length; j+=7)
					{	
						let innerText = "<div class=\"prviDioCelije\">"+(j+1)+"</div>"
									  + "<div class=\"drugiDioCelijeZauzeta\" style=\"background-color: rgb(255, 169, 169)\"></div>";
							
						nizNepraznihCelijaTabele[j].innerHTML = innerText;
					}
				}
			}
		}
		
		//za VANREDNA zauzeca
		for(let i=0; i<nizVanrednihZauzeca.length; i++)
		{
			if(mjesec == (nizVanrednihZauzeca[i].datum).split(".")[1]-1 && 
				(nizVanrednihZauzeca[i].datum).split(".")[2] == korisnikGledaGodinu &&
			    daLiSePoklapajuIntervali(vrijemePocetka, vrijemeKraja, nizVanrednihZauzeca[i].pocetak, nizVanrednihZauzeca[i].kraj) && 
			    sala == nizVanrednihZauzeca[i].naziv)
			{
				let danUMjesecu = Number((nizVanrednihZauzeca[i].datum).split(".")[0]);
				nizNepraznihCelijaTabele[danUMjesecu-1].innerHTML = "<div class=\"prviDioCelije\">"+danUMjesecu+"</div>" 
																  + "<div class=\"drugiDioCelijeZauzeta\" style=\"background-color: rgb(199, 92, 238)\"></div>";
			}
		}
	}
	
	function daLiSePoklapajuIntervali(pocetak1, kraj1, pocetak2, kraj2)
	{
		// II nacin (moglo se je sve prevesti i u minute):
		pocetak1 = pocetak1.split(":")[0]*60 + pocetak1.split(":")[1];
		kraj1 = kraj1.split(":")[0]*60 + kraj1.split(":")[1];
		pocetak2 = pocetak2.split(":")[0]*60 + pocetak2.split(":")[1];
		kraj2 = kraj2.split(":")[0]*60 + kraj2.split(":")[1];
		
		//uradjena konverzija iz stringa u int, jer je bremena poredio kao stringove
		pocetak1 = parseInt(pocetak1);
		kraj1 = parseInt(kraj1);
		pocetak2 = parseInt(pocetak2);
		kraj2 = parseInt(kraj2);
		
		return( (kraj1 > pocetak2 && kraj1 <= kraj2) || 
			    (pocetak1 >= pocetak2 && pocetak1 < kraj2) ||
			    (pocetak1 < pocetak2 && kraj1 > kraj2) ||
				(pocetak1 <= pocetak2 && kraj1 > kraj2) ||
				(pocetak1 < pocetak2 && kraj1 >= kraj2) );
				
		
		//s obzirom da su istom formatu vremena, sto je obaveno postavkom uciniti, stringovi ce se porediti kao stvarno vrijeme bez potrebe za 
		// pretvaranjem u minute - https://stackoverflow.com/questions/43733099/javascript-difference-between-two-time-strings/43733200
	}
	
	//ovaj return mora biti u liniji sa '{', jer ga jedino tako interpreter prepoznaje,  inace se pojavljuje "Uncaught SyntaxError: Unexpected token ':'"
	return {
		obojiZauzeca: obojiZauzecaImpl,
		ucitajPodatke: ucitajPodatkeImpl,
		iscrtajKalendar: iscrtajKalendarImpl,
		daLiSePreklapajuDvaIntervala: daLiSePoklapajuIntervali 
	}
	
} ());

//prvo punjenje tabele na pocetku, prikazuje se trenutni mjesec
var kalendarIzHTMLa = document.getElementById("kalendar");
Kalendar.iscrtajKalendar(kalendarIzHTMLa, new Date().getMonth());

var dugmeSljedeci = document.getElementById("dugmeSljedeci");
var dugmePrethodni = document.getElementById("dugmePrethodni");

var listaZaOdabirSale = document.getElementById("listaSalaSForme");
var pocetakVrijemeSForme = document.getElementById("pocetakVrijemeSForme");
var krajVrijemeSForme = document.getElementById("krajVrijemeSForme");

//globalna varijbala, BRISE SE TEK NAKON STO SE STRANICA UGASI
var saltajIGodine = false;

dugmePrethodni.addEventListener("click", function(ev)
{	
		if(saltajIGodine == true)
		{
			if(korisnikGledaMjesec == 0)
			{
				korisnikGledaMjesec = 11;
				korisnikGledaGodinu --;
			}
			else
			{
				korisnikGledaMjesec --;
			}
		}
		else
		{
			if(korisnikGledaMjesec == 0)
				dugmePrethodni.disabled = true;
			else 
			{
				dugmePrethodni.disabled = false;
				korisnikGledaMjesec --;
				dugmeSljedeci.disabled = false;
				
				if(korisnikGledaMjesec == 0)
					dugmePrethodni.disabled = true;
			}
				
		}
		
		Kalendar.iscrtajKalendar(kalendarIzHTMLa, korisnikGledaMjesec);
		
		if( validacijaPodatakaForme() == true)
			Kalendar.obojiZauzeca(kalendarIzHTMLa, korisnikGledaMjesec, listaZaOdabirSale.options[listaZaOdabirSale.selectedIndex].value, pocetakVrijemeSForme.value, 
								krajVrijemeSForme.value);
		
	});
		
dugmeSljedeci.addEventListener("click", function(ev)
{
		if(saltajIGodine == true)
		{
			if(korisnikGledaMjesec == 11)
			{
				korisnikGledaMjesec = 0;
				korisnikGledaGodinu ++;
			}
			else
			{
				korisnikGledaMjesec ++;
			}
		}
		else
		{
			if(korisnikGledaMjesec == 11)
				dugmeSljedeci.disabled = true;
			else
			{
				dugmeSljedeci.disabled = false;
				korisnikGledaMjesec++;
				dugmePrethodni.disabled = false;
				
				if(korisnikGledaMjesec == 11)
					dugmeSljedeci.disabled = true;
			}
		}
		
		Kalendar.iscrtajKalendar(kalendarIzHTMLa, korisnikGledaMjesec);
		
		if( validacijaPodatakaForme() == true)
			Kalendar.obojiZauzeca(kalendarIzHTMLa, korisnikGledaMjesec, listaZaOdabirSale.options[listaZaOdabirSale.selectedIndex].value, pocetakVrijemeSForme.value, 
								krajVrijemeSForme.value);
		
	});
	
listaZaOdabirSale.addEventListener("change", function(ev){
		
		if( validacijaPodatakaForme() == true)
			Kalendar.obojiZauzeca(kalendarIzHTMLa, korisnikGledaMjesec, listaZaOdabirSale.options[listaZaOdabirSale.selectedIndex].value, pocetakVrijemeSForme.value, 
								krajVrijemeSForme.value);
	});

pocetakVrijemeSForme.addEventListener("change", function(ev){
		if( validacijaPodatakaForme() == true)
			Kalendar.obojiZauzeca(kalendarIzHTMLa, korisnikGledaMjesec, listaZaOdabirSale.options[listaZaOdabirSale.selectedIndex].value, pocetakVrijemeSForme.value, 
								krajVrijemeSForme.value);
	});
	
krajVrijemeSForme.addEventListener("change", function(ev){
		if( validacijaPodatakaForme() == true)
			Kalendar.obojiZauzeca(kalendarIzHTMLa, korisnikGledaMjesec, listaZaOdabirSale.options[listaZaOdabirSale.selectedIndex].value, pocetakVrijemeSForme.value, 
								krajVrijemeSForme.value);
	});
	
function validacijaPodatakaForme()
{
	if(pocetakVrijemeSForme == null || krajVrijemeSForme == null || pocetakVrijemeSForme.value == "" || krajVrijemeSForme.value == "")
		return false;
	
	let pocetnoVrijemeUMinutama = pocetakVrijemeSForme.value.split(":")[0]*60 + pocetakVrijemeSForme.value.split(":")[1];		
	let krajnjeVrijemeUMinutama = krajVrijemeSForme.value.split(":")[0]*60 +krajVrijemeSForme.value.split(":")[1];
	
	pocetnoVrijemeUMinutama = parseInt(pocetnoVrijemeUMinutama);
	krajnjeVrijemeUMinutama = parseInt(krajnjeVrijemeUMinutama);
	
	if(pocetnoVrijemeUMinutama >= krajnjeVrijemeUMinutama)
		return false;
	
	return true;
}

if(korisnikGledaMjesec == 11)
	dugmeSljedeci.disabled = true;
else if(korisnikGledaMjesec == 0)
	dugmePrethodni.disabled = true;

//hard kodirani podaci
/*Kalendar.ucitajPodatke(
						[
							{
								dan: 5,
								semestar: "zimski",
								pocetak: "12:00",
								kraj: "13:00",
								naziv: "0-01",
								predavac: "NH"
							}, 
							{
								dan: 4,
								semestar: "ljetni",
								pocetak: "12:00",
								kraj: "13:30",
								naziv: "VA1",
								predavac: "NH"
							}
						], 
						[
							{
								datum: "21.11.2019",
								pocetak: "12:00",
								kraj: "13:30",
								naziv: "1-01",
								predavac: "Nadija"
							}, 
							{
								datum: "5.7.2019",
								pocetak: "12:00",
								kraj: "14:00",
								naziv: "MA",
								predavac: "Nedzad"
							}
						]
					);*/

//SAMO U SVRHU TESTIRANJA BEZ PROMJENE PODATAKA U ELEMNTIMA FORME (TJ. ELEMENTIMA IZNAD KALENDARA)
//zimski semestar, sve srijede(dan:2) treba da fija obojiZauzeca oboji u pink
//Kalendar.obojiZauzeca(kalendarIzHTMLa, 0, "0-01", "12:30", "19:00"); //treba se odrazit
//Kalendar.obojiZauzeca(kalendarIzHTMLa, 9, "0-01", "13:29", "14:00"); //treba se odrazit
//Kalendar.obojiZauzeca(kalendarIzHTMLa, , "0-01", "13:30", "14:00"); //ne treba se odrazit
//Kalendar.obojiZauzeca(kalendarIzHTMLa, 10, "0-01", "10:00", "20:00"); //treba se odrazit
//Kalendar.obojiZauzeca(kalendarIzHTMLa, 11, "0-01", "10:00", "12:01"); //treba se odrazit
//Kalendar.obojiZauzeca(kalendarIzHTMLa, 0, "0-01", "12:01", "13:29"); //treba se odrazit

//ljetni semestar, svaki petak(dan:4) treba da fija obojiZauzeca oboji u pink
//Kalendar.obojiZauzeca(kalendarIzHTMLa, 3, "VA1", "12:30", "19:00"); //treba
//Kalendar.obojiZauzeca(kalendarIzHTMLa, 4, "VA1", "13:29", "14:00"); //treba 
//Kalendar.obojiZauzeca(kalendarIzHTMLa, 3, "VA1", "13:30", "14:00"); //ne treba
//Kalendar.obojiZauzeca(kalendarIzHTMLa, 5, "VA1", "10:00", "20:00"); //treba
//Kalendar.obojiZauzeca(kalendarIzHTMLa, 6, "VA1", "10:00", "12:01"); //treba
  
//Kalendar.obojiZauzeca(kalendarIzHTMLa, 11, "1-01", "12:00", "20:00"); // treba da se oboji 5.7.2019.
//Kalendar.obojiZauzeca(kalendarIzHTMLa, 7, "MA", "11:59", "14:00");
