let tijeloStranice = document.getElementById("sadrzaj");

var innerText = "<div id=\"triSlike\">"
                +"</div>"
                +"<div class=\"dugmadDiv\">"
				    +"<button id=\"dugmePrethodni\" class=\"dugmePrethodni\" type=\"button\" disabled>Prethodni</button>"
				    +"<button id=\"dugmeSljedeci\" class=\"dugmeSljedeci\" type=\"button\">Sljedeci</button>"
				    +"<div></div>"
                +"</div>";

tijeloStranice.innerHTML = innerText;

var dugmeSljedeci = document.getElementById("dugmeSljedeci");
var dugmePrethodni = document.getElementById("dugmePrethodni");

dugmePrethodni.addEventListener("click", function(ev)
{
    Pozivi.zadatak3Prethodni();
});
    
dugmeSljedeci.addEventListener("click", function(ev)
{
    Pozivi.zadatak3Sljedeci();
});

Pozivi.zadatak3Sljedeci();
