
function ucitaj(){
    Poziv.osobljePoSalama();
    setInterval(function(){
        Poziv.osobljePoSalama();
    }, 30000);
   
}