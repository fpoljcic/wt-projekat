var div = document.getElementsByClassName("galerija");
var slikaElement = document.createElement("div");
var dugmeLijevo;
var dugmeDesno;
function slike(body){
    
    //div[0].appendChild(slikaElement);
    if(Poziv.postaviSlike())
        Poziv.prikaziSlike(document.getElementsByClassName("galerija")[0]);
        dugmeLijevo = document.getElementById("prethodni");
        dugmeDesno = document.getElementById("sljedeci");
        dugmeLijevo.disabled = true;
}
function klikniPrethodni(btn){
    Poziv.klikniLijevo(dugmeLijevo, dugmeDesno, document.getElementsByClassName("galerija")[0]);
}
function klikniSljedeci(btn){
    Poziv.klikniDesno(dugmeLijevo, dugmeDesno, document.getElementsByClassName("galerija")[0]);
}