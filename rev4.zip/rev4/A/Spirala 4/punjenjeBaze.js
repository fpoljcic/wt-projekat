/*const db = require('./db.js');
db.sequelize.sync({force:true}).then(function(){
    inicializacija().then(function(){
        console.log("Baza kreirana!");
        process.exit();
    });
});*/
    /*function inicializacijaImpl(){
        var osobljeLista = [];
        var rezervacijeLista = [];
        var terminiLista = [];
        var saleLista = [];
        
        return new Promise(function(resolve, reject){
            osobljeLista.push(db.osobljeModel.create({ime: 'Neko', prezime: 'Nekic', uloga: 'profesor'}));
            osobljeLista.push(db.osobljeModel.create({ime: 'Drugi', prezime: 'Neko', uloga: 'asistent'}));
            osobljeLista.push(db.osobljeModel.create({ime: 'Test', prezime: 'Test', uloga: 'asistent'}));
            
            terminiLista.push(db.terminModel.create({redovni: false, dan: null, datum: "01.01.2020", semestar: null, pocetak: "12:00", kraj: "13:00"}));
            terminiLista.push(db.terminModel.create({redovni: true, dan: 0, datum: null, semestar: "zimski", pocetak: "13:00", kraj: "14:00"}));
            
            Promise.all(osobljeLista).then(function(osoblje){
                var neko = osoblje.filter(function(a){return a.ime === 'Neko'})[0].dataValues.id;
                var drugi = osoblje.filter(function(a){return a.ime === 'Drugi'})[0].dataValues.id;
                var test = osoblje.filter(function(a){return a.ime === 'Test'})[0].dataValues.id;

                Promise.all(terminiLista).then(function(termini){
                    var termin1 = termini.filter(function(t){return t.id == 1})[0].dataValues.id;
                    var termin2 = termini.filter(function(t){return t.id == 2})[0].dataValues.id;

                    saleLista.push(
                        db.salaModel.create({naziv:'1-11'}).then(function(s){
                            s.setOsoblje([neko]);
                            return new Promise(function(resolve, reject){resolve(s);});
                        })
                    );
                    saleLista.push(
                        db.salaModel.create({naziv: '1-15'}).then(function(s){
                            s.setOsoblje([drugi]);
                            return new Promise(function(resolve,reject){resolve(s);});
                        })
                    );
                    Promise.all(saleLista).then(function(sale){
                        var sala1 = sale.filter(function(s){return s.naziv == '1-11'})[0].dataValues.id;
                        var sala2 = sale.filter(function(s){return s.naziv == '1-15'})[0].dataValues.id;

                        rezervacijeLista.push(
                            db.rezervacijaModel.create({}).then(function(r){
                                r.setOsoblje([neko]);
                                r.setTermin([termin1]);
                                r.setSala([sala1]);
                                return new Promise(function(resolve,reject){resolve(r);});
                            })
                        );
                        rezervacijeLista.push(
                            db.rezervacijaModel.create({}).then(function(r){
                                    r.setOsoblje([test]);
                                    r.setTermin([termin2]);
                                    r.setSala([sala1]);
                                    return new Promise(function(resolve,reject){resolve(r);});
                                })
                        );
                    })
                })
            })
        })
    }*/