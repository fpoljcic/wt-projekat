var assert = chai.assert;
describe('spirala 4', () => {
 describe('GET/osoblje', () => {
   //Pozivanje obojiZauzeca kada podaci nisu učitani: očekivana vrijednost da se ne oboji niti jedan dan
   it('Pozivanje obojiZauzeca kada podaci nisu učitani', () => {
   //Poziv.ucitajProfesore();
        var ajax = new XMLHttpRequest();
        ajax.overrideMimeType("application/json");
        ajax.open('GET', 'http://localhost:8080/osoblje', true);
        ajax.onreadystatechange = function (){
            console.log(ajax.readyState + ' '+ ajax.status);
            if(ajax.readyState == 4 && ajax.status == "200"){
                console.log(this.responseText);
            }
        }
     assert.equal(counter, 0,"Error!");
   })
  });
});
