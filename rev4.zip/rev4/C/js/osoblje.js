var olOsobljeSala=document.getElementById("osobljeUsali");
var pocPredavaci=[];
var osobljeDjeca;
Pozivi.ucitajOsobeAjax(olOsobljeSala,1);
setInterval(function(){Pozivi.ucitajZauzecaAjax(1);},30000);
